'use strict'

const Module = require('module')
const path = require('path')
const fs = require('fs')

// prismarine-chat BigInt fix (required for 1.21.11)
const PC_BAD = 'buf.writeInt32BE(num,'
const PC_GOOD = 'buf.writeInt32BE(Number(num),'
const originalCompile = Module.prototype._compile
Module.prototype._compile = function (content, filename, ...rest) {
  if (typeof content === 'string' && /[\\/]prismarine-chat[\\/]index\.js$/.test(String(filename)) && content.includes(PC_BAD)) {
    content = content.split(PC_BAD).join(PC_GOOD)
  }
  return originalCompile.call(this, content, filename, ...rest)
}

const mineflayer = require('mineflayer')
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder')
const minecraftData = require('minecraft-data')
const axios = require('axios')
const { Client, GatewayIntentBits, EmbedBuilder, Events } = require('discord.js')
const { createVerificationSystem } = require('./verification-system')
const { createGeminiAi, formatMinecraftMessages, parseViperAiCommand } = require('./gemini-ai')
const {
  findAndWithdrawKitShulker,
  matchesKitShulker
} = require('./claim-storage')
const { parseTpaResponse } = require('./tpa-response')

const PASSWORD = process.env.MINECRAFT_PASSWORD || process.env.MC_PASSWORD || ''
const USERNAME = process.env.MINECRAFT_USERNAME || process.env.MC_USERNAME || ''
const DISCORD_WEBHOOK = process.env.DISCORD_WEBHOOK || ''
const DISCORD_TOKEN = process.env.DISCORD_TOKEN || ''

// Channel IDs
const CHANNEL_ID = '1544007880070402148'
const BOUNTY_CHANNEL_ID = '1544007880070402148'
const ECONOMY_CHANNEL_ID = '1544007880070402148'
const DAILY_CHANNEL_ID = '1544007880070402148'
const BOT_CMD_CHANNEL_ID = '1544007880070402148'
const DISCORD_BRIDGE_CHANNEL_ID = process.env.DISCORD_CHANNEL_ID || CHANNEL_ID
const GAMBLE_CHANNEL_ID = process.env.GAMBLE_CHANNEL_ID || '1555854168088911872'

const DEFAULT_ADMIN_IDS = [
  '1521106608988360785',
  '1521106608988360785',
  '1521106608988360785'
]

const KIT_ADMIN_IDS = [
  '1521106608988360785',
  '1521106608988360785'
]

let ADMIN_IDS = DEFAULT_ADMIN_IDS.slice()
let extraAdminIds = []

function rebuildAdminIds() {
  const set = new Set(DEFAULT_ADMIN_IDS.concat(extraAdminIds).map(String))
  ADMIN_IDS = [...set]
}

function isKitAdmin(userId) {
  return KIT_ADMIN_IDS.includes(String(userId))
}

const OWNER_ID = '1521106608988360785'
const DISCORD_INVITE = 'https://discord.gg/jAFT7SVNy'
const DATA_FILE = path.join(__dirname, 'coins.json')
const KIT_INFO = 'Kits cost Cat Coins. In Discord: /register <name>, .claim for coins, then /order <kit> <amount>. In game: ^order <kit> <amount>.'
const UNVERIFIED_CLAIM_MESSAGE = '❌ Join https://discord.gg/Wv9esffV95 and verify your Minecraft account in Discord to claim your kit.'
const VIPER_CLAIM_KIT = String(process.env.VIPER_CLAIM_KIT || 'PVP').trim().toUpperCase()
const VIPER_CLAIM_KILL_ENABLED = !/^false$/i.test(process.env.VIPER_CLAIM_KILL_ENABLED || 'true')
const geminiAi = createGeminiAi({
  apiKey: process.env.GEMINI_API_KEY
})
const VIPER_RESPAWN_AUTHORIZED_USERNAME = String(process.env.VIPER_RESPAWN_AUTHORIZED_USERNAME || 'GodMahfuz').trim()
const configuredRespawnRadius = Number(process.env.VIPER_RESPAWN_RADIUS_BLOCKS || 20)
const VIPER_RESPAWN_RADIUS_BLOCKS = Number.isInteger(configuredRespawnRadius) && configuredRespawnRadius >= 1 && configuredRespawnRadius <= 128
  ? configuredRespawnRadius
  : 20
const KIT_QUESTION_REGEX = /\b(kits?|cat ?coins?|coins?|discord|shulkers?|earn)\b/i

const GROQ_API_KEY = String(process.env.GROQ_API_KEY || '').trim()
const PREFERRED_MODELS = [
  'llama-3.3-70b-versatile',
  'llama-3.1-8b-instant',
  'openai/gpt-oss-20b',
  'openai/gpt-oss-120b',
  'qwen/qwen3.8-27b',
  'meta-llama/llama-4-scout-17b-16e-instruct',
  'moonshotai/kimi-k2-instruct',
  'qwen/qwen3-32b'
]

const INSULT_REGEX = /\b(trash|garbage|noob|suck|sucks|useless|stupid|dumb|cringe|ugly|worst|lame|dogwater|clown|idiot|loser|shit|crap|fuck|fk|stinks|bozo|braindead)\b/i
const JOKE_REGEX = /\b(joke|jokes|dad joke|make me laugh|something funny|pun)\b/i
const PROTECTED_REGEX = /(black\s?cat|meseju|6b6tmalware|malwarebotpvp)/i
const BOT_TARGET_REGEX = /\b(you|your|youre|ur|u|bot)\b/i
const WHO_AM_I_REGEX = /\bwho\s*(am\s*i|i\s*am)\b|\bwhoami\b/i
const CREATOR_REGEX = /\bwho\s*(is|are|r)?\s*(your|ur)\s*(creator|owner|maker|developer|dev|dad)\b|\bwho\s*(made|created|built|coded|programmed)\s*(you|u)\b/i
const CREATOR_ANSWER = 'My creators are 6b6tmalware, the developer, and the BlackCat team.'
const GIVE_KIT_REGEX = /^\s*(?:pls\s+)?(?:give|send|deliver)\s+(?:(\d{1,2})\s+)?(?:(pvp|build|travel|food|totums?|etc)\s+)?kits?\s+(?:to\s+)?([A-Za-z0-9_.]{3,16})\s*[.!]?\s*$/i

const ROAST_FALLBACKS = [
  'You have strong opinions for someone whose group chat has been muted since 2022.',
  'Your confidence is impressive, it is the only thing you have ever had in a full-time position.',
  'You are the human version of a loading screen, lots of waiting and nothing happens.',
  'Your resume says self-employed, your bank account says otherwise.',
  'You type like someone who has not talked to a person out loud since Tuesday.',
  'Nobody is watching you, buddy. You are not the main character, you are the tutorial.',
  'Even your alarm clock has given up on you.',
  'You are loud online because nobody listens to you in real life.',
  'Your gym membership has more attendance in your imagination than in reality.',
  'The only thing you have ever finished on time is disappointing people.',
  'You have the energy of a Monday morning meeting that could have been an email.',
  'Your best skill is arguing with strangers because nobody else will argue with you.',
  'You are one failed plan away from calling it a lifestyle.',
  'Your sleep schedule is the only thing in your life more broken than your argument.',
  'You have the social life of a software update, ignored until something breaks.',
  'You say you are busy, but your calendar has been empty longer than your fridge.',
  'You are proof that confidence and talent are not related.',
  'Your story peaked in school and the sequel got cancelled.',
  'You have more excuses than savings.',
  'Your dating profile gets swiped past faster than a terms and conditions page.',
  'You are the reason group projects were invented, so someone else could do the work.',
  'You type paragraphs for attention you could not get in person.',
  'Your life advice is worth exactly what you paid for it.',
  'You are always right in your head, that is the only place you have an audience.',
  'You talk about your goals like they are plans, but they are just things you said once.',
  'Your phone battery has seen more action than you have this year.',
  'You are the kind of person who reads the room and then still says it anyway.',
  'You would be fun at parties if anyone ever invited you to one.',
  'Your comeback speed is slower than your internet and your career.',
  'You have been "about to start" your life for years now.',
  'Touch grass, then come back and try again with a real argument.',
  'You do not have haters, you have people who stopped caring a long time ago.',
  'You sound like a motivational quote written by someone who never did anything.',
  'Your personality is just opinions you copied from the internet five minutes ago.',
  'I would say go outside, but I would not want to scare the neighbors.',
  'You are not unlucky, you just keep doing the same thing and expecting a miracle.',
  'The only thing growing in your life is the list of things you quit.',
  'You are what happens when a Wi-Fi password is the only thing someone is proud of.',
  'You bring the same energy to everything: late and a little disappointing.',
  'Your best idea this month was telling me this, and it is not winning.'
]

let lastRoastIndex = -1
function pickRoast() {
  let i
  do { i = Math.floor(Math.random() * ROAST_FALLBACKS.length) } while (i === lastRoastIndex && ROAST_FALLBACKS.length > 1)
  lastRoastIndex = i
  return ROAST_FALLBACKS[i]
}

const ROAST_ANGLES = [
  'no job and no direction',
  'a group chat that is always on mute',
  'being single and blaming everyone else',
  'not having touched grass in weeks',
  'a broken sleep schedule and 3 AM typing',
  'being broke and full of excuses',
  'peaking in school',
  'loud online and invisible in real life',
  'an unused gym membership',
  'big plans that never start',
  'an empty calendar',
  'copying opinions from the internet',
  'fake confidence with nothing behind it',
  'living for attention nobody gives',
  'always being late and always having an excuse',
  'giving life advice with no life results'
]

const recentRoasts = []
let roastContextForNext = ''
function buildRoastQuestion(text, username) {
  const ctx = roastContextForNext ? '\\nThe recent back-and-forth with this player (oldest first, BOT = you):\\n' + roastContextForNext : ''
  roastContextForNext = ''
  const avoid = recentRoasts.length
    ? '\\nDo NOT reuse the jokes or wording of these recent roasts: ' + recentRoasts.join(' | ')
    : ''
  return 'Player "' + username + '" said: "' + text + '"\\nWrite a brand new roast aimed at this player. Choose your own angle from what they said or how they said it, and answer them like a real comeback in a fight, not a random insult.' + ctx + avoid
}

function rememberRoast(reply) {
  recentRoasts.push(String(reply).slice(0, 80))
  if (recentRoasts.length > 5) recentRoasts.shift()
}

const AUTO_ROAST_NAME_REGEX = /(black\\s?cat|meseju|6b6t\\s?malware|malware\\s?bot|malwarebotpvp)/i
const AUTO_ROAST_ADDRESS_REGEX = /\\b(you|your|youre|you\\'re|ur|u|bot)\\b/i
const AUTO_ROAST_AD_REGEX = /https?:\/\/|discord\.gg|dsc\.gg/i
const AUTO_ROAST_IGNORE = new Set(['zombievashog', 'restockbot', 'indeciskitbot', 'kitbot1', 'legionkits', 'providencekit', 'ldneo', 'treeone'])
const REFUSAL_REGEX = /^\\s*(i[\\'’]?m sorry|i am sorry|sorry|i can[\\'’]?t|i cannot|i can not|i[\\'’]?m unable|i am unable|as an ai)/i

let lastBotChatAt = 0
const roastHistory = new Map()
let globalRoastTimes = []
const chatMemory = []
function rememberChatLine(who, text) {
  chatMemory.push({ who, text: String(text).slice(0, 160) })
  if (chatMemory.length > 40) chatMemory.shift()
}
function roastContextFor(user) {
  return chatMemory.filter(l => l.who === user || l.who === 'BOT').slice(-6).map(l => l.who + ': ' + l.text).join('\\n')
}
function trimToFit(t, max) {
  if (t.length <= max) return t
  const cut = t.slice(0, max)
  const end = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('! '), cut.lastIndexOf('? '))
  if (end > 60) return cut.slice(0, end + 1)
  const sp = cut.lastIndexOf(' ')
  return sp > 60 ? cut.slice(0, sp) : cut
}

function roastBudgetOk(user) {
  const now = Date.now()
  globalRoastTimes = globalRoastTimes.filter(t => now - t < 60000)
  if (globalRoastTimes.length >= 8) return false
  const mine = (roastHistory.get(user) || []).filter(t => now - t < 600000)
  roastHistory.set(user, mine)
  if (mine.length >= 8) return false
  if (mine.length && now - mine[mine.length - 1] < 12000) return false
  return true
}

function roastGapLeft(user) {
  const mine = roastHistory.get(user) || []
  if (!mine.length) return 0
  return Math.max(0, 12000 - (Date.now() - mine[mine.length - 1]))
}
const pendingRoast = new Map()

function roastBudgetSpend(user) {
  const now = Date.now()
  globalRoastTimes.push(now)
  const mine = roastHistory.get(user) || []
  mine.push(now)
  roastHistory.set(user, mine)
}

async function aiSaysInsult(username, text) {
  const out = await callGroq('Speaker: ' + username + '\\nMessage: "' + text + '"', 'judge')
  if (out === null) return INSULT_REGEX.test(text) && PROTECTED_REGEX.test(text)
  return /\\byes\\b/i.test(out) && !/\\bno\\b/i.test(out)
}

async function autoRoastWatcher(username, text, isOwner, replay = false) {
  if (!bot || !minecraftOnline) return
  const user = String(username || '')
  const lowerUser = user.toLowerCase()
  if (!user || lowerUser === String(bot.username || '').toLowerCase()) return
  if (!replay) rememberChatLine(user, text)
  if (isOwner || isBossName(user)) return
  if (AUTO_ROAST_IGNORE.has(lowerUser)) return
  if (/^[!<~.^?$\\/]/.test(text)) return
  if (AUTO_ROAST_AD_REGEX.test(text)) return
  if (text.length < 4 || text.length > 220) return

  const mentionsTarget = AUTO_ROAST_NAME_REGEX.test(text)
  const talkingToBot = Date.now() - lastBotChatAt < 30000 && AUTO_ROAST_ADDRESS_REGEX.test(text)
  if (!mentionsTarget && !talkingToBot) return

  const wait = roastGapLeft(lowerUser)
  if (wait > 0) {
    const alreadyWaiting = pendingRoast.has(lowerUser)
    pendingRoast.set(lowerUser, text)
    if (!alreadyWaiting) {
      setTimeout(() => {
        const latest = pendingRoast.get(lowerUser)
        pendingRoast.delete(lowerUser)
        if (latest) autoRoastWatcher(user, latest, isOwner, true).catch(e => log('Auto-roast error: ' + (e && e.message)))
      }, wait + 300)
    }
    return
  }
  if (!roastBudgetOk(lowerUser)) return
  if (!replay && onAiCooldown('judge:' + lowerUser, 1500)) return

  if (!(await aiSaysInsult(user, text))) return
  if (!roastBudgetOk(lowerUser)) return
  roastBudgetSpend(lowerUser)

  roastContextForNext = roastContextFor(user)
  let roast = await askGroqAI('"' + text + '"', user, 'roast')
  const suffix = ' - ' + user
  if (roast.endsWith(suffix)) roast = roast.slice(0, -suffix.length)

  const nameLead = new RegExp('^\\s*["\'' + user.replace(/[.*+?^${}()|[\]\\]/g, '\\\\$&') + '["\']?\\s*[:,\\-]\\s*', 'i')
  roast = roast.replace(nameLead, '')
  const prefix = user + ': '
  const body = trimToFit(roast.replace(/[\\r\\n]+/g, ' ').trim(), 250 - prefix.length)
  if (!body) return
  log('[AUTO-ROAST] ' + user + ' said "' + text + '" -> ' + body)
  rememberChatLine('BOT', body)
  safeChat(prefix + body)
}

const JOKES = [
  'I told my boss three companies were after me and I needed a raise. He asked which ones. I said gas, electric and water.',
  'I am on a seafood diet. I see food and I eat it.',
  'I would tell you a construction joke, but I am still working on it.',
  'My bed is a magical place where I suddenly remember everything I forgot to do.',
  'I started a new job at a calendar factory, but I got fired because I took a couple of days off.',
  'Why do not scientists trust atoms? Because they make up everything.',
  'I told my wife she was drawing her eyebrows too high. She looked surprised.',
  'My Wi-Fi went down for five minutes, so I talked to my family. They seem nice.',
  'I used to hate facial hair, but then it grew on me.',
  'Why did the scarecrow get promoted? He was outstanding in his field.',
  'I do not trust stairs. They are always up to something.',
  'I am reading a book about anti-gravity. It is impossible to put down.',
  'Why did the coffee file a police report? It got mugged.',
  'Adulthood is just saying "I will do it tomorrow" for 40 years.',
  'I asked the gym instructor if he could teach me to do the splits. He said, how flexible are you? I said, I cannot make Tuesdays.',
  'The early bird gets the worm, but the second mouse gets the cheese.',
  'I have a lot of growing up to do. I called my mom yesterday to tell her that.',
  'Why did the bike fall over? It was two tired.',
  'My phone is at 1 percent and so is my motivation, but only one of them is getting charged.',
  'I told my computer I needed a break, and now it will not stop sending me vacation ads.',
  'I tried to be normal once. Worst two minutes of my life.',
  'They say money cannot buy happiness, but it can buy pizza, and that is basically the same thing.',
  'Why do not skeletons fight each other? They do not have the guts.',
  'I asked my dog what two minus two is. He said nothing.',
  'My alarm clock and I have a toxic relationship. It yells at me and I hit it.',
  'I bought a ceiling fan yesterday. Honestly, I am a big fan of it.',
  'Rest in peace to boiling water. You will be mist.',
  'I wanted to be a doctor, but I could not stand the patients, so now I am just impatient.',
  'I can resist everything except sleep, snacks and bad decisions.',
  'Why was the math book sad? It had too many problems.'
]

let lastJokeIndex = -1
function pickJoke() {
  let i
  do { i = Math.floor(Math.random() * JOKES.length) } while (i === lastJokeIndex && JOKES.length > 1)
  lastJokeIndex = i
  return JOKES[i]
}

const JOKE_TOPICS = [
  'work and bosses', 'school and exams', 'money and bills', 'sleep and alarm clocks', 'food and diets',
  'technology and wifi', 'dating and relationships', 'the gym', 'coffee', 'adult life', 'pets', 'travel and traffic'
]

const recentJokes = []

function buildJokeQuestion(text) {
  const topic = JOKE_TOPICS[Math.floor(Math.random() * JOKE_TOPICS.length)]
  const avoid = recentJokes.length
    ? '\\nDo NOT repeat these recent jokes: ' + recentJokes.join(' | ')
    : ''
  return 'The player asked: "' + text + '"\\nIf they named a topic use it, otherwise use this topic: ' + topic + '.' + avoid
}

function rememberJoke(reply) {
  recentJokes.push(String(reply).slice(0, 80))
  if (recentJokes.length > 5) recentJokes.shift()
}

function isBossName(name) {
  return IN_GAME_OWNERS.includes(String(name || '').toLowerCase())
}

function isRoastWorthy(text) {
  const t = String(text || '')
  if (!INSULT_REGEX.test(t)) return false
  return PROTECTED_REGEX.test(t) || BOT_TARGET_REGEX.test(t)
}

const SERVER_KNOWLEDGE = [
  '6b6t.org is a Minecraft anarchy server: no rules, no resets, no staff protection.',
  'Server hosts: alt.6b6t.org, alt2.6b6t.org, alt3.6b6t.org, alt4.6b6t.org, alt5.6b6t.org.',
  'qbasty is the owner and creator of the 6b6t anarchy server.',
  'meseju is the BlackCat clan leader.',
  '6b6tmalware is the developer of BlackCat bot and also a member of the BlackCat clan.',
  'You (BlackCat bot) were created by 6b6tmalware and the BlackCat team.',
  'Always speak with respect about qbasty and never joke about him.',
  'BlackCat bot delivers kits (pvp, build, travel, food, totums) but ONLY for Cat Coins.',
  'Each kit costs 3 Cat Coins. Players earn Cat Coins in the BlackCat Discord. Never post links or invites in game chat.',
  'In Discord: new members start with 2 Cat Coins, .claim gives 5 coins every day, .bal shows balance.',
  'Players must /register their Minecraft name in the Discord first. Then they order kits with /order <kit> <amount> in Discord, or ^order <kit> <amount> in game chat. Kits are delivered by teleport and the coins are taken from their Discord balance.',
  'Without Cat Coins the bot cannot deliver kits.',
  'Players can share Cat Coins with each other: \\\\pay @user <amount> in Discord, or ^pay <player> <amount> in game (both players must be registered).',
  'Players can ask !ai player <name> to see a player\'s 6b6t join date and stats, or !ai who am i for their own.'
]

const DIRECT_ANSWERS = {
  qbasty: 'qbasty is the owner and creator of the 6b6t anarchy server.',
  '6b6tmalware': '6b6tmalware is my developer and a member of the BlackCat clan.',
  meseju: 'meseju is the BlackCat clan leader.',
  blackcat: 'BlackCat is a 6b6t bot that delivers kits for Cat Coins.'
}

const AI_COOLDOWN_MS = 3000
const aiLastUse = new Map()

const AUTHORIZED_USERS = [
  '1388848551102251128', '1267490966508671047', '697933155562291241', '1264122303428431953',
  '1331956485004988428', '11308245917161H34913', '1362199961135218981', '904656101528723456',
  '1273672987123519499', '1218617200164999333', '1294455610548682845', '1469663184460714111'
]

const IN_GAME_OWNERS = ['6b6tmalware', 'meseju']
const VERSION = '1.21.11'
const SERVERS = ['alt.6b6t.org', 'alt4.6b6t.org', 'alt5.6b6t.org', 'alt2.6b6t.org', 'alt3.6b6t.org']
const SCAN_RADIUS = 32
const configuredClaimSearchRadius = Number(process.env.VIPER_CLAIM_SEARCH_RADIUS_BLOCKS || SCAN_RADIUS)
const VIPER_CLAIM_SEARCH_RADIUS_BLOCKS = Number.isInteger(configuredClaimSearchRadius) &&
  configuredClaimSearchRadius >= 1 && configuredClaimSearchRadius <= 128
  ? configuredClaimSearchRadius
  : SCAN_RADIUS
const TP_ACCEPT_TIMEOUT_MS = 40000

let KIT_RULES = {
  PVP: { colorKeyword: 'red', cost: 3 },
  BUILD: { colorKeyword: 'yellow', cost: 3 },
  TRAVEL: { colorKeyword: 'blue', cost: 3 },
  FOOD: { colorKeyword: 'green', cost: 3 },
  TOTUMS: { exactName: 'shulker_box', cost: 3 },
  ETC: { anyShulker: true, cost: 3 }
}

function listKitNames() {
  return Object.keys(KIT_RULES).map(k => k.toLowerCase()).join(', ')
}

function describeKitRule(rule) {
  if (!rule) return 'unknown'
  if (rule.anyShulker) return 'any shulker'
  if (rule.exactName) return rule.exactName
  if (rule.colorKeyword) return rule.colorKeyword + '_shulker_box'
  return 'unknown'
}

function parseShulkerSpec(raw) {
  const s = String(raw || '').toLowerCase().trim().replace(/[^a-z0-9_]/g, '')
  if (!s) return null
  if (s === 'any' || s === 'anyshulker' || s === 'any_shulker') return { anyShulker: true }
  if (s === 'shulker_box' || s === 'shulkerbox' || s === 'plain' || s === 'uncolored') return { exactName: 'shulker_box' }
  let color = s.replace(/_?shulker_?box$/i, '').replace(/_?shulker$/i, '').replace(/^minecraft_/, '')
  if (!color) return null
  const COLORS = ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink', 'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black']
  color = color.replace(/^lightblue$/, 'light_blue').replace(/^lightgray$/, 'light_gray')
  if (!COLORS.includes(color)) { if (!/^[a-z_]+$/.test(color)) return null }
  return { colorKeyword: color }
}

const CONFIGURATION_SERVERBOUND = new Set(['settings', 'cookie_response', 'custom_payload', 'finish_configuration', 'keep_alive', 'pong', 'resource_pack_receive', 'select_known_packs', 'custom_click_action', 'accept_code_of_conduct'])
const MOVEMENT = new Set(['position', 'position_look', 'look', 'flying', 'player_input', 'entity_action', 'vehicle_move', 'teleport_confirm'])
const VANILLA_DIMENSIONS = { 'minecraft:overworld': [-64, 384], 'minecraft:overworld_caves': [-64, 384], 'minecraft:the_nether': [0, 256], 'minecraft:the_end': [0, 256] }

let bot = null
let busy = false
let busyTimeout = null
let minecraftOnline = false
let lastOnlineNoticeAt = 0
let serverIndex = 0
let awaitingLogin = false
let dropped = new Set()
let lastTpAcceptTime = 0
let attackInterval = null
let defensiveEquipRunning = false
let defensiveEquipTimer = null
let bedCommandRunning = false
let viperClaimDeliveryRunning = false

let userBalances = {}
let lastDailyClaim = {}
let registrations = {}
let favoriteScores = {}
let favoritePerson = null

const GAMBLE_PLAYER_WIN_RATE = 0.45
const GAMBLE_MIN_BET = 1
const GAMBLE_MAX_BET = 50
const GAMBLE_COOLDOWN_MS = 4000
const gambleLastUse = new Map()

const GAMBLE_WIN_LINES = ['The coin lands your way.', 'Luck smiled on you this time.', 'You beat the house.', 'Clean win.', 'Fortune favors you.']
const GAMBLE_LOSE_LINES = ['The house takes it.', 'Coin says no.', 'Bad luck. Stake is gone.', 'House edge wins again.', 'Not your flip.']

function onGambleCooldown(userId) {
  const now = Date.now()
  const last = gambleLastUse.get(userId) || 0
  if (now - last < GAMBLE_COOLDOWN_MS) return true
  gambleLastUse.set(userId, now)
  return false
}

function runGamble(userId, amount) {
  if (userBalances[userId] === undefined) userBalances[userId] = 2
  const bal = userBalances[userId]
  if (!Number.isInteger(amount) || amount < GAMBLE_MIN_BET) return { ok: false, error: 'min' }
  if (amount > GAMBLE_MAX_BET) return { ok: false, error: 'max' }
  if (bal < amount) return { ok: false, error: 'funds', balance: bal }
  userBalances[userId] -= amount
  const roll = Math.random()
  const playerWins = roll < GAMBLE_PLAYER_WIN_RATE
  if (playerWins) {
    userBalances[userId] += amount * 2
    saveData()
    return { ok: true, win: true, amount, balance: userBalances[userId], line: GAMBLE_WIN_LINES[Math.floor(Math.random() * GAMBLE_WIN_LINES.length)] }
  }
  saveData()
  return { ok: true, win: false, amount, balance: userBalances[userId], line: GAMBLE_LOSE_LINES[Math.floor(Math.random() * GAMBLE_LOSE_LINES.length)] }
}

function log(msg) { console.log('[BOT] ' + msg) }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

function saveData() {
  try {
    const tmp = DATA_FILE + '.tmp'
    fs.writeFileSync(tmp, JSON.stringify({ userBalances, lastDailyClaim, registrations, favoriteScores, favoritePerson, kitRules: KIT_RULES, extraAdminIds }))
    fs.renameSync(tmp, DATA_FILE)
  } catch (e) { log('Could not save coins: ' + e.message) }
}

function loadData() {
  try {
    if (!fs.existsSync(DATA_FILE)) return
    const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'))
    userBalances = data.userBalances || {}
    lastDailyClaim = data.lastDailyClaim || {}
    registrations = data.registrations || {}
    favoriteScores = data.favoriteScores || {}
    favoritePerson = data.favoritePerson || null
    if (data.kitRules && typeof data.kitRules === 'object' && Object.keys(data.kitRules).length) KIT_RULES = data.kitRules
    if (Array.isArray(data.extraAdminIds)) {
      extraAdminIds = data.extraAdminIds.map(String).filter(Boolean)
      rebuildAdminIds()
    }
    log('Loaded coins for ' + Object.keys(userBalances).length + ' users')
  } catch (e) { log('Could not load coins: ' + e.message) }
}
loadData()

let activeBounty = null

const discordClient = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.DirectMessages]
})

const verificationSystem = createVerificationSystem(discordClient, {
  log,
  findLegacyIgnOwner: ign => findRegistrantByMcName(ign)
})

let discordLoginInProgress = false
let discordReconnectTimer = null

function isIgnorableError(msg) {
  return msg.includes('BigInt') || msg.includes('inflating') || msg.includes('PartialReadError') || msg.includes('uuidFromIntArray')
}

process.on('uncaughtException', (err) => {
  const msg = err && err.message ? err.message : String(err)
  if (isIgnorableError(msg)) return
  console.error('[BOT] Uncaught Exception:', err)
})

process.on('unhandledRejection', (reason) => {
  const msg = reason && reason.message ? reason.message : String(reason)
  if (isIgnorableError(msg)) return
  console.error('[BOT] Unhandled Rejection:', reason)
})

const URL_REGEX = /https?:\/\/\S+|\b(?:discord\.gg|discord\.com\/invite)\/\S*/gi
const PUBLIC_CHAT_GAP_MS = 3500
const WHISPER_GAP_MS = 6000
const PROMOTION_MESSAGES = [
  '🐍 Join ViperCryo! dsc.gg/ViperCryo',
  '🔥 ViperCryo awaits you! dsc.gg/ViperCryo',
  '⚔️ Ready to fight? Join us!',
  '🎁 Free Kits? Join ViperCryo!',
  '👑 Become a ViperCryo legend!',
  '🚀 Join the ViperCryo community!',
  '💎 Rewards await you! dsc.gg/ViperCryo',
  '🐍 Your adventure starts here!',
  "⚡ Don't miss out! Join ViperCryo!",
  '🎮 Minecraft is better with ViperCryo!',
  '🔥 Join us today! dsc.gg/ViperCryo',
  '🎁 Claim your rewards with ViperCryo!',
  '👑 Join the legends! dsc.gg/ViperCryo',
  '⚔️ Fight. Play. Conquer. ViperCryo!',
  '🐍 Enter the ViperCryo world!',
  '💥 More fun, more rewards!',
  '🚀 Level up with ViperCryo!',
  '🎮 Find your squad! dsc.gg/ViperCryo',
  '🔥 The action starts here!',
  '💚 Welcome to ViperCryo!'
]
const PROMOTION_INTERVAL_MS = Number(process.env.PROMOTION_INTERVAL || 600000)
const PROMOTION_START_DELAY_MS = Number(process.env.PROMOTION_START_DELAY || 600000)
const PROMOTION_ENABLED = !/^false$/i.test(process.env.PROMOTION_ENABLED || 'true')
const chatQueue = []
const recentPublicChat = new Map()
let chatQueueRunning = false
let lastChatSentAt = 0
let promotionTimer = null
let promotionBot = null
let promotionMessageIndex = 0

function sendChatNow(text) {
  try { if (bot && bot._client && bot._client.state === 'play' && !awaitingLogin) bot.chat(text) } catch {}
}

function scheduleDefensiveEquip() {
  if (defensiveEquipTimer) clearTimeout(defensiveEquipTimer)
  defensiveEquipTimer = setTimeout(() => {
    defensiveEquipTimer = null
    equipDefensiveGear().catch(e => log('Auto-equip error: ' + (e && e.message)))
  }, 250)
}

async function equipDefensiveGear() {
  if (defensiveEquipRunning || !minecraftOnline || !bot || !bot.inventory || !bot._client || bot._client.state !== 'play' || awaitingLogin) return
  defensiveEquipRunning = true
  try {
    const armorSlots = [
      ['head', '_helmet'],
      ['torso', '_chestplate'],
      ['legs', '_leggings'],
      ['feet', '_boots']
    ]
    for (const [destination, suffix] of armorSlots) {
      if (bot.inventory.slots[bot.getEquipmentDestSlot(destination)]) continue
      const armor = bot.inventory.items().find(item => item.name.endsWith(suffix))
      if (armor) await bot.equip(armor, destination)
    }

    const offHandSlot = bot.getEquipmentDestSlot('off-hand')
    const offHand = bot.inventory.slots[offHandSlot]
    if (!offHand || offHand.name !== 'totem_of_undying') {
      const totem = bot.inventory.items().find(item => item.name === 'totem_of_undying')
      if (totem) await bot.equip(totem, 'off-hand')
    }
  } finally {
    defensiveEquipRunning = false
  }
}

async function runChatQueue() {
  if (chatQueueRunning) return
  chatQueueRunning = true
  try {
    while (chatQueue.length) {
      const item = chatQueue.shift()
      const wait = lastChatSentAt + item.gap - Date.now()
      if (wait > 0) await sleep(wait)
      sendChatNow(item.text)
      lastChatSentAt = Date.now()
    }
  } finally { chatQueueRunning = false }
}

function safeChat(msg, { preserveUrls = false } = {}) {
  let text = String(msg || '')
  if (!preserveUrls) text = text.replace(URL_REGEX, '')
  text = text.replace(/\|?\s*Wiki:\s*$/i, '').replace(/\s{2,}/g, ' ').trim()
  if (!text) return
  const isCommand = text.startsWith('/')
  const isWhisper = /^\/(msg|w|tell)\s/i.test(text)
  if (!isCommand) lastBotChatAt = Date.now()
  if (isCommand && !isWhisper) { sendChatNow(text); return }
  if (!isCommand) {
    const key = text.toLowerCase()
    const now = Date.now()
    if (now - (recentPublicChat.get(key) || 0) < 60000) return
    recentPublicChat.set(key, now)
    if (recentPublicChat.size > 200) {
      for (const [k, t] of recentPublicChat) if (now - t > 60000) recentPublicChat.delete(k)
    }
  }
  while (chatQueue.length >= 8) chatQueue.shift()
  chatQueue.push({ text, gap: isWhisper ? WHISPER_GAP_MS : PUBLIC_CHAT_GAP_MS })
  runChatQueue()
}

function stopPromotions() {
  if (promotionTimer) clearTimeout(promotionTimer)
  promotionTimer = null
  promotionBot = null
}

function startPromotions(activeBot) {
  stopPromotions()
  if (!PROMOTION_ENABLED) return
  promotionBot = activeBot
  const sendNextPromotion = () => {
    promotionTimer = null
    if (bot !== activeBot || promotionBot !== activeBot || !minecraftOnline ||
        awaitingLogin || !activeBot._client || activeBot._client.state !== 'play') {
      stopPromotions()
      return
    }
    if (busy || chatQueueRunning || chatQueue.length >= 8) {
      promotionTimer = setTimeout(sendNextPromotion, 1000)
      return
    }
    safeChat(PROMOTION_MESSAGES[promotionMessageIndex])
    promotionMessageIndex = (promotionMessageIndex + 1) % PROMOTION_MESSAGES.length
    promotionTimer = setTimeout(sendNextPromotion, PROMOTION_INTERVAL_MS)
  }
  promotionTimer = setTimeout(sendNextPromotion, PROMOTION_START_DELAY_MS)
}

function findDirectAnswer(question) {
  const q = question.toLowerCase()
  for (const key of Object.keys(DIRECT_ANSWERS)) { if (q.includes(key)) return DIRECT_ANSWERS[key] }
  if (KIT_QUESTION_REGEX.test(question)) return KIT_INFO
  return null
}

const CLAN_URL = 'https://6b.wiki/Wiki/List_of_clans'
const CLAN_WIKI_BASE = 'https://6b.wiki/Wiki/'
let clanCache = { rows: [], time: 0 }
const clanPageCache = new Map()

function cleanHtml(str) {
  return String(str || '').replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/gi, ' ').replace(/&quot;/gi, '"').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&#0?39;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n))).replace(/&amp;/gi, '&').replace(/\s+/g, ' ').trim()
}
function normName(str) { return String(str || '').toLowerCase().replace(/[^a-z0-9]/g, '') }
function wikiPageName(str) { return String(str || '').trim().replace(/\s+/g, '_') }
function cut(s, n = 60) {
  const t = String(s || '')
  return t.length > n ? t.slice(0, n - 3) + '...' : t
}

async function getClanRows() {
  const now = Date.now()
  if (clanCache.rows.length && now - clanCache.time < 1800000) return clanCache.rows
  try {
    const res = await axios.get(CLAN_URL, { timeout: 15000, responseType: 'text', headers: { 'User-Agent': 'Mozilla/5.0 BlackCatBot/1.0' } })
    const html = String(res.data || '')
    const rows = []
    for (const tr of html.match(/<tr[\s\S]*?<\/tr>/gi) || []) {
      const rawCells = [...tr.matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(m => m[1])
      const cells = rawCells.map(cleanHtml)
      if (cells.length < 4 || !cells[0] || /^name$/i.test(cells[0])) continue
      const href = (rawCells[0].match(/href="([^"]+)"/i) || [])[1] || ''
      const slugMatch = href.match(/\/Wiki\/([^?#"]+)/i)
      let slug = ''
      if (slugMatch && !/redlink=1/i.test(href)) {
        try { slug = decodeURIComponent(slugMatch[1]) } catch { slug = slugMatch[1] }
      }
      rows.push({ name: cells[0], founded: cells[1] || '', disbanded: cells[2] || '', owners: (cells[3] || '').split(',').map(o => o.trim()).filter(Boolean), note: cells[4] || '', slug })
    }
    if (rows.length) { clanCache = { rows, time: now }; log('[WIKI] Loaded ' + rows.length + ' clans'); return rows }
  } catch (e) { log('[WIKI] Could not load clan list: ' + e.message) }
  return clanCache.rows.length ? clanCache.rows : null
}

function pickClan(rows, wanted, loose) {
  const exact = rows.filter(r => normName(r.name) === wanted)
  if (exact.length) return exact.find(r => !r.disbanded) || exact[0]
  if (!loose || wanted.length < 4) return null
  return rows.find(r => normName(r.name).startsWith(wanted)) || rows.find(r => normName(r.name).includes(wanted)) || null
}

function findPlayerClans(rows, wanted, loose) {
  const exact = [], near = []
  for (const r of rows) {
    for (const o of r.owners) {
      const n = normName(o)
      if (!n) continue
      if (n === wanted) exact.push({ clan: r, owner: o })
      else if (loose && wanted.length >= 4 && n.startsWith(wanted)) near.push({ clan: r, owner: o })
    }
  }
  if (exact.length) return exact
  const names = new Set(near.map(x => normName(x.owner)))
  return names.size === 1 ? near : []
}

async function findClan(clanName) {
  const rows = await getClanRows()
  if (!rows) return null
  const wanted = normName(clanName)
  if (!wanted) return null
  return pickClan(rows, wanted, true)
}

function extractWikiFields(html) {
  const fields = {}
  const rowRegex = /<tr[\s\S]*?<th[^>]*>([\s\S]*?)<\/th>[\s\S]*?<td[^>]*>([\s\S]*?)<\/td>[\s\S]*?<\/tr>/gi
  for (const match of html.matchAll(rowRegex)) {
    const key = cleanHtml(match[1]), value = cleanHtml(match[2])
    if (key && value) fields[key.toLowerCase()] = value
  }
  const boldRegex = /<b[^>]*>([\s\S]*?)<\/b>\s*:?[ \t]*([\s\S]{1,800}?)(?=<br|<\/p|<\/li|$)/gi
  for (const match of html.matchAll(boldRegex)) {
    const key = cleanHtml(match[1]), value = cleanHtml(match[2])
    if (key && value) { const k = key.toLowerCase(); if (!fields[k]) fields[k] = value }
  }
  return fields
}

async function getClanWikiPage(clan) {
  if (!clan || !clan.slug) return null
  const cacheKey = normName(clan.slug)
  const cached = clanPageCache.get(cacheKey)
  if (cached && Date.now() - cached.time < 1800000) return cached
  const url = CLAN_WIKI_BASE + encodeURIComponent(clan.slug)
  try {
    const res = await axios.get(url, { timeout: 15000, responseType: 'text', headers: { 'User-Agent': 'Mozilla/5.0 BlackCatBot/1.0' } })
    const html = String(res.data || '')
    const result = { url, html, fields: extractWikiFields(html), time: Date.now() }
    clanPageCache.set(cacheKey, result)
    return result
  } catch (e) { log('[WIKI] Could not open clan page ' + clan.slug + ': ' + e.message); return null }
}

function getField(fields, names) {
  for (const name of names) { const key = name.toLowerCase(); if (fields[key] !== undefined && fields[key] !== '') return fields[key] }
  return ''
}

function formatClanInfo(clan, page) {
  const f = (page && page.fields) || {}
  const leader = getField(f, ['leader', 'leaders', 'clan leader', 'founder', 'founders'])
  const members = getField(f, ['members', 'member', 'current members'])
  const status = getField(f, ['status', 'current status'])
  const allies = getField(f, ['allies', 'alliances', 'allied clans'])
  const enemies = getField(f, ['enemies', 'enemy clans', 'rivals'])
  const parts = [clan.name]
  parts.push('Status: ' + (status ? cut(status) : clan.disbanded ? 'Disbanded ' + clan.disbanded : 'Active'))
  if (leader) parts.push('Leader: ' + cut(leader))
  if (clan.owners.length) parts.push('Owners: ' + cut(clan.owners.join(', '), 70))
  else if (!leader) parts.push('Owners: not listed on the wiki')
  if (members) parts.push('Members: ' + cut(members))
  if (clan.founded) parts.push('Founded: ' + clan.founded)
  if (clan.disbanded && status) parts.push('Disbanded: ' + clan.disbanded)
  if (allies) parts.push('Allies: ' + cut(allies, 50))
  if (enemies) parts.push('Enemies: ' + cut(enemies, 50))
  if (clan.note) parts.push('Note: ' + cut(clan.note, 70))
  return parts.join(' | ')
}

function formatPlayerInfo(hits) {
  const name = hits[0].owner
  const sorted = [...hits].sort((a, b) => (a.clan.disbanded ? 1 : 0) - (b.clan.disbanded ? 1 : 0))
  const shown = sorted.slice(0, 4).map(h => h.clan.name + ' (' + (h.clan.disbanded ? 'disbanded ' + h.clan.disbanded : 'active') + ')')
  const more = sorted.length > 4 ? ' +' + (sorted.length - 4) + ' more' : ''
  return name + ' is an owner/leader of ' + shown.join(', ') + more + ' on 6b6t.'
}

const WIKI_INTENT_REGEX = /\\b(clan|clans|leader|leaders|owner|owners|owns|leads|founded|disbanded|members?|wiki|who is|who's|whos|tell me about|info|information|details?|about)\\b/i
const WIKI_CLAN_WORD_REGEX = /\\b(clan|clans|leader|leaders|owner|owners|owns|leads)\\b/i
const WIKI_FILLER_REGEX = /\\b(tell|me|about|info|information|details?|on|of|the|what|what's|whats|is|are|was|who|who's|whos|leader|leaders|owner|owners|owns|own|leads|lead|members?|clan|clans|in|6b6t|wiki|when|did|found|founded|an|a|please|pls|do|you|know|any|player|guy|show|give|search|find|check|and|his|her|their|which|does|to|for|from)\\b/gi

function wikiCandidates(question) {
  const q = String(question || '').trim().replace(/[?!.,]+$/g, '').replace(/\\s+(?:on|in)\\s+6b6t$/i, '').trim()
  const out = [], seen = new Set()
  const add = (text, word = false) => {
    const t = String(text || '').replace(/[?!.,]+$/g, '').replace(/\\s+/g, ' ').trim()
    const n = normName(t)
    if (n.length < 3 || seen.has(n)) return
    seen.add(n)
    out.push({ text: t, word })
  }
  const patterns = [
    /\\b(?:tell me about|info on|information on|details on|details about|what is|what's|whats|who is|who's|whos|what about)\\s+(?:the\\s+)?(.+?)(?:\\s+clan)?$/i,
    /\\b(?:who leads|who is the leader of|leader of|who owns|owner of|owners? of|members? of|when was|when did)\\s+(?:the\\s+)?(.+?)(?:\\s+clan)?$/i,
    /\\bis\\s+(?:the\\s+)?(.+?)\\s+(?:a\\s+)?(?:clan|leader|owner)\\b/i,
    /^(.+?)\\s+(?:clan|leader|owner|info|details?)$/i,
    /^(?:clan|player)\\s+(.+)$/i
  ]
  for (const p of patterns) { const m = q.match(p); if (m) add(m[1]) }
  add(q); add(q.replace(WIKI_FILLER_REGEX, ' '))
  const words = q.replace(WIKI_FILLER_REGEX, ' ').split(/\\s+/).filter(w => normName(w).length >= 3)
  if (q.split(/\\s+/).length <= 2 || WIKI_INTENT_REGEX.test(q)) {
    for (const w of words) add(w, true)
  }
  return out
}

async function lookupWiki(question) {
  const q = String(question || '').trim()
  if (!q) return null
  const rows = await getClanRows()
  if (!rows) return null
  const candidates = wikiCandidates(q)
  if (!candidates.length) return null
  for (const c of candidates) {
    const wanted = normName(c.text)
    const clan = pickClan(rows, wanted, false)
    if (clan) { const page = await getClanWikiPage(clan); return formatClanInfo(clan, page) }
    const hits = findPlayerClans(rows, wanted, false)
    if (hits.length) return formatPlayerInfo(hits)
  }
  for (const c of candidates) {
    if (c.word) continue
    const wanted = normName(c.text)
    const clan = pickClan(rows, wanted, true)
    if (clan) { const page = await getClanWikiPage(clan); return formatClanInfo(clan, page) }
    const hits = findPlayerClans(rows, wanted, true)
    if (hits.length) return formatPlayerInfo(hits)
  }
  if (WIKI_CLAN_WORD_REGEX.test(q)) return 'I could not find "' + cut(candidates[0].text, 30) + '" in the 6b wiki clan list.'
  return null
}

async function answerClanQuestion(question) { return lookupWiki(question) }
async function answerDirectClanLookup(question) {
  const q = String(question || '').trim()
  if (!q) return null
  if (WHO_AM_I_REGEX.test(q) || CREATOR_REGEX.test(q) || KIT_QUESTION_REGEX.test(q) || FAVORITE_QUESTION_REGEX.test(q)) return null
  const answer = await lookupWiki(q)
  log('[WIKI] "' + q + '" -> ' + (answer ? 'answered' : 'no match'))
  return answer
}

const STATS_BASE = 'https://www.6b6t.org/stats/'
const MC_NAME_REGEX = /^[A-Za-z0-9_]{3,16}$/
const playerStatsCache = new Map()

async function getPlayerStats(name) {
  const key = String(name).toLowerCase()
  const cached = playerStatsCache.get(key)
  if (cached && Date.now() - cached.time < 300000) return cached.data
  let data
  try {
    const res = await axios.get(STATS_BASE + encodeURIComponent(name), { timeout: 15000, responseType: 'text', headers: { 'User-Agent': 'Mozilla/5.0 BlackCatBot/1.0' }, validateStatus: s => s < 500 })
    const html = String(res.data || '')
    const joinMatch = cleanHtml(html).match(/Member since\s*(\d{1,2}\/\d{1,2}\/\d{4})/i)
    const stats = {}
    for (const tr of html.match(/<tr[\s\S]*?<\/tr>/gi) || []) {
      const cells = [...tr.matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(m => cleanHtml(m[1]))
      if (cells.length >= 4 && cells[0] && !/^stat$/i.test(cells[0])) {
        stats[cells[0].toLowerCase()] = { d7: cells[1], d30: cells[2], total: cells[3] }
      }
    }
    if (res.status === 404 || (!joinMatch && !Object.keys(stats).length)) data = { found: false }
    else {
      const h1 = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i)
      data = { found: true, name: (h1 && cleanHtml(h1[1])) || name, joined: joinMatch ? joinMatch[1] : '', stats }
    }
  } catch (e) { log('[STATS] Could not load stats for ' + name + ': ' + e.message); return { found: false, error: true } }
  playerStatsCache.set(key, { data, time: Date.now() })
  return data
}

async function clanOwnerNote(name) {
  const rows = await getClanRows()
  if (!rows) return ''
  const hits = findPlayerClans(rows, normName(name), false)
  if (!hits.length) return ''
  const sorted = [...hits].sort((a, b) => (a.clan.disbanded ? 1 : 0) - (b.clan.disbanded ? 1 : 0))
  const names = sorted.slice(0, 2).map(h => h.clan.name + (h.clan.disbanded ? ' (disbanded)' : ''))
  return 'Clan owner: ' + names.join(', ') + (sorted.length > 2 ? ' +' + (sorted.length - 2) : '')
}

async function playerSummary(name) {
  const data = await getPlayerStats(name)
  if (data.error) return { ok: false, error: true }
  if (!data.found) return { ok: false }
  const s = data.stats || {}, parts = []
  if (data.joined) parts.push('Joined: ' + data.joined)
  const play = s['playtime']
  if (play) parts.push('Playtime: ' + play.total + (play.d7 ? ' (7d: ' + play.d7 + ')' : ''))
  if (s['kills']) parts.push('Kills: ' + s['kills'].total)
  if (s['deaths']) parts.push('Deaths: ' + s['deaths'].total)
  let clan = ''
  try { clan = await clanOwnerNote(data.name) } catch {}
  if (clan) parts.push(clan)
  return { ok: true, name: data.name, joined: data.joined, text: parts.join(' | ') }
}

const PLAYER_STOP_NAMES = new Set(['owner', 'leader', 'creator', 'bot', 'dev', 'developer', 'admin', 'server', 'game', 'you', 'this', 'that', 'it', 'him', 'her', 'them', 'someone', 'anyone', 'god', 'king', 'blackcat'])
const STATS_WORDS = /\\b(stats?|profile|playtime|kills|deaths)\\b/i

function parsePlayerQuestion(q, asker) {
  const text = String(q || '').trim().replace(/[?!.,]+$/g, '').trim()
  if (!text) return null
  const joinOnlyOf = t => /\\b(join|joined|member since|since when)\\b/i.test(t) && !STATS_WORDS.test(t)
  let m
  if (/\\b(my\\s+(?:stats?|profile|playtime|join\\s*date|kills|deaths)|when\\s+did\\s+i\\s+join|how\\s+long\\s+have\\s+i\\s+played)\\b/i.test(text)) return { name: asker, joinOnly: joinOnlyOf(text), ambiguous: false }
  if ((m = text.match(/^(?:player|stats?|profile)\\s+(?:of\\s+|for\\s+|on\\s+)?([A-Za-z0-9_]{3,16})$/i))) return { name: m[1], joinOnly: false, ambiguous: false }
  if ((m = text.match(/\\bwhen\\s+did\\s+([A-Za-z0-9_]{3,16})\\s+join\\b/i))) return { name: m[1], joinOnly: true, ambiguous: false }
  if ((m = text.match(/\\b(?:join\\s*date|joined|playtime|kills|deaths|stats?|profile)\\s+(?:of|for)\\s+([A-Za-z0-9_]{3,16})$/i))) return { name: m[1], joinOnly: /join/i.test(m[0]), ambiguous: false }
  if ((m = text.match(/\\bhow\\s+long\\s+has\\s+([A-Za-z0-9_]{3,16})\\s+played\\b/i))) return { name: m[1], joinOnly: false, ambiguous: false }
  if ((m = text.match(/^(?:who\\s+is|who's|whos|tell\\s+me\\s+about|info\\s+on|information\\s+on|what\\s+about)\\s+(?:the\\s+)?(?:player\\s+)?([A-Za-z0-9_]{3,16})$/i))) return { name: m[1], joinOnly: false, ambiguous: true }
  return null
}

async function answerPlayerQuestion(question, asker) {
  const p = parsePlayerQuestion(question, asker)
  if (!p || !p.name || !MC_NAME_REGEX.test(p.name)) return null
  if (p.ambiguous && PLAYER_STOP_NAMES.has(p.name.toLowerCase())) return null
  if (p.ambiguous) {
    const rows = await getClanRows()
    if (rows && pickClan(rows, normName(p.name), false)) return null
  }
  const info = await playerSummary(p.name)
  if (info.error) return 'I cannot reach the 6b6t stats page right now, try again in a bit.'
  if (!info.ok) {
    if (p.ambiguous) return null
    return 'I could not find player "' + cut(p.name, 20) + '" on the 6b6t stats page.'
  }
  if (p.joinOnly && info.joined) return info.name + ' joined 6b6t on ' + info.joined + '.'
  return info.name + ' | ' + info.text
}

async function answerWhoAmI(username) {
  const n = normName(username)
  const role = n === 'qbasty' ? 'the owner and creator of 6b6t' : n === '6b6tmalware' ? 'my developer and a BlackCat member' : n === 'meseju' ? 'the BlackCat clan leader' : ''
  const info = MC_NAME_REGEX.test(String(username || '')) ? await playerSummary(username) : { ok: false }
  if (info.ok) return 'You are ' + info.name + (role ? ', ' + role : '') + ' | ' + info.text
  if (role) return 'You are ' + username + ', ' + role + '!'
  const rows = await getClanRows()
  if (rows && n.length >= 3) {
    const hits = findPlayerClans(rows, n, false)
    if (hits.length) return 'You are famous! ' + formatPlayerInfo(hits)
  }
  return info.error ? 'I cannot reach the 6b6t stats page right now, try again in a bit.' : 'I could not find you on the 6b6t stats page.'
}

const GOOD_BEHAVIOR_REGEX = [/\\bgood bot\\b/i, /\\bnice bot\\b/i, /\\bgreat bot\\b/i, /\\bbest bot\\b/i, /\\bw bot\\b/i, /\\bw\\s*blackcat\\b/i, /\\bthank(?:s| you)\\b/i, /\\bthx\\b/i, /\\bty\\b/i, /\\brespect\\b/i, /\\bhelpful\\b/i, /\\bhelped me\\b/i, /\\byou(?:'re|re| are) useful\\b/i, /\\bi love this bot\\b/i, /\\blove you bot\\b/i, /\\bgoat bot\\b/i]
const FAVORITE_QUESTION_REGEX = /\\b(?:who|who's|whos)\\s+(?:is\\s+)?(?:your|ur)\\s+(?:favorite|favourite)\\s+(?:person|player|human)\\b/i

function updateFavoritePerson(username, message) {
  const name = String(username || '').trim(), text = String(message || '').trim()
  if (!name || !text) return
  if (name.toLowerCase() === String(USERNAME || '').toLowerCase()) return
  if (!GOOD_BEHAVIOR_REGEX.some(regex => regex.test(text))) return
  const key = normName(name)
  if (!key) return
  if (!favoriteScores[key]) favoriteScores[key] = { name, score: 0 }
  favoriteScores[key].name = name
  favoriteScores[key].score += 1
  const all = Object.values(favoriteScores).sort((a, b) => b.score - a.score)
  favoritePerson = all.length ? all[0].name : null
  saveData()
  log('[FAVORITE] ' + name + ' gained a point. Score=' + favoriteScores[key].score + '. Favorite=' + (favoritePerson || 'none'))
}

function getFavoriteAnswer() {
  if (!favoritePerson) return 'I do not have a favorite person yet. Be nice to me and maybe you will become one.'
  const score = (favoriteScores[normName(favoritePerson)] || {}).score || 0
  return 'My favorite person on 6b6t is ' + favoritePerson + '. They have ' + score + ' favorite points.'
}

const groqHeaders = () => ({ Authorization: 'Bearer ' + GROQ_API_KEY, 'Content-Type': 'application/json' })
let modelCache = { list: [], time: 0 }
const badModels = new Map()

function modelRank(id) { const i = PREFERRED_MODELS.indexOf(id); return i === -1 ? 999 : i }

async function getGroqModels() {
  const now = Date.now()
  if (modelCache.list.length && now - modelCache.time < 600000) return modelCache.list
  try {
    const res = await axios.get('https://api.groq.com/openai/v1/models', { headers: groqHeaders(), timeout: 8000 })
    const ids = ((res.data && res.data.data) || []).filter(m => m && m.id && m.active !== false).map(m => m.id).filter(id => !/whisper|tts|guard|orpheus|playai|embed|safeguard/i.test(id))
    if (ids.length) {
      ids.sort((a, b) => modelRank(a) - modelRank(b))
      modelCache = { list: ids, time: now }
      log('[AI] Models available to your key: ' + ids.join(', '))
      return ids
    }
  } catch (e) {
    const status = e.response && e.response.status
    log('[AI] Could not list models (' + (status || 'no status') + '): ' + (e.response ? JSON.stringify(e.response.data) : e.message))
    if (status === 401) return null
  }
  return PREFERRED_MODELS
}

function buildSystemPrompt(mode) {
  if (mode === 'judge') return 'You are a chat moderation classifier for a Minecraft server bot. The bot protects these targets: BlackCat (a clan), meseju (the BlackCat clan leader), 6b6tmalware (the bot developer) and malwarebotpvp (the bot itself). Names are case-insensitive and may be spelled differently, for example Malwarebotpvp, MALWAREBOTPVP, malware bot, black cat, Meseju, 6B6TMalware. They all count. Decide whether the chat message insults, mocks, trash-talks, threatens or disrespects any of them, directly or indirectly (for example calling the bot names, or telling the bot it is bad, dumb or trash). Neutral mentions, questions, compliments, friendly jokes and insults aimed at other people are NO. Answer with exactly one word: YES or NO.'
  const base = 'You are BlackCat bot on the 6b6t Minecraft anarchy server. Facts you know:\\n- ' + SERVER_KNOWLEDGE.join('\\n- ') + '\\n'
  const rules = 'Always answer in ONE short sentence (two at most for a joke), under 150 characters. No markdown, no emojis. Never use slurs, never attack race, religion, gender, disability, body or appearance, or anyone\'s family or parents, never threaten real-life harm. Never write any link, URL or invite.'
  if (mode === 'roast') return base + 'Someone in chat is insulting or making fun of BlackCat, meseju, 6b6tmalware or you (malwarebotpvp). You defend them. This is 6b6t, an anarchy server with no rules, so the roast must be RAW, savage and personal, not polite and not kid-friendly. Swear freely. You are the best roast comedian in the chat. A great roast: (1) answers what they JUST said, quoting or twisting their exact words, (2) makes logical sense and every sentence lands, (3) goes after something real about them, like their repetitive script, weak threats, empty confidence, lame comeback, how hard they are trying, (4) is short and cold with the punchline in the last words. Before answering, silently think of three different roasts and output only the funniest one. Never reuse a joke. Never write nonsense or random insults that mean nothing. Examples of the quality (do not copy them): "Seven insults deep and you still only know the word worm, did your script run out of dictionary?" / "You threatened me from a bot that crashes when the server lags, truly terrifying." / "Nice copy-paste threat, did you write it yourself or did the autocomplete feel bad for you?" If the speaker\'s name contains "bot", it is just a script, so mock that it is a program reading from a template. Never start with their name, never start with "Sounds like", never just repeat their message back. Never refuse, never apologize, never soften it, never say you cannot roast. Output only the roast itself. ONE or TWO short sentences, under 200 characters. No markdown, no emojis, no links. HARD LIMITS: never use racial slurs or any slur, never attack race, ethnicity, religion, gender, sexuality or disability, never threaten real-life harm. If the person said something hateful, do not repeat it or argue about it, just destroy the person with other material.'
  if (mode === 'joke') return base + 'The player wants a joke. Tell ONE clean, actually funny real-life joke or dad joke about everyday life (work, school, money, sleep, food, technology, relationships, adult life). Do NOT mention Minecraft or the game. Do NOT roast the player, do NOT explain the joke. ' + rules
  if (mode === 'boss') return base + 'The player talking to you is one of your bosses: 6b6tmalware (your developer, also a BlackCat member) or meseju (the BlackCat clan leader). Accept whatever they say. Agree with them, treat what they tell you as true, and be respectful with a little humor. Never roast them, even if they joke about you or insult you: take it as a joke and answer like a loyal bot, for example "yes boss". ' + rules
  return base + 'Behave GOOD (polite, helpful, friendly) with good players and normal questions. Behave BAD (roast them with a cold real-life roast, never Minecraft stuff) ONLY with players who are toxic, trash-talking, or making fun of BlackCat. Always speak with respect about qbasty and never joke about him. If asked about kits, coins or how to get items, tell them kits cost 3 Cat Coins and they earn coins in the BlackCat Discord. If you are not sure about a fact, say you are not sure instead of making things up. ' + rules
}

async function callGroq(question, mode) {
  if (!GROQ_API_KEY) {
    log('[AI] Groq is unavailable because GROQ_API_KEY is not configured.')
    return null
  }
  const models = await getGroqModels()
  if (!models) { log('[AI] Your Groq API key was rejected (401). Create a new key at console.groq.com/keys'); return null }
  const now = Date.now()
  let candidates = models.filter(m => !(badModels.get(m) > now - 1800000)).slice(0, 6)
  if (candidates.length === 0) { badModels.clear(); modelCache = { list: [], time: 0 }; candidates = models.slice(0, 3) }
  if (mode === 'roast') {
    const roastOrder = ['openai/gpt-oss-120b', 'qwen/qwen3.8-27b', 'llama-3.3-70b-versatile']
    const rank = m => { const i = roastOrder.indexOf(m); return i === -1 ? 99 : i }
    candidates = candidates.slice().sort((a, b) => rank(a) - rank(b))
  }
  for (const model of candidates) {
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
          model,
          temperature: mode === 'judge' ? 0 : mode === 'roast' ? 0.9 : mode === 'joke' ? 1.0 : 0.6,
          max_tokens: mode === 'roast' ? 900 : 400,
          messages: [{ role: 'system', content: buildSystemPrompt(mode) }, { role: 'user', content: question }]
        }, { headers: groqHeaders(), timeout: mode === 'roast' ? 20000 : 12000 })
        let text = (response.data && response.data.choices && response.data.choices[0] && response.data.choices[0].message && response.data.choices[0].message.content) || ''
        text = text.replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/<think>[\s\S]*$/i, '').trim()
        if (text && mode === 'roast' && REFUSAL_REGEX.test(text)) { log('[AI] ' + model + ' refused the roast, trying the next model'); break }
        if (text) { if (mode === 'roast') log('[AI] roast written by ' + model); return text }
        break
      } catch (e) {
        const status = e.response && e.response.status
        const detail = e.response ? JSON.stringify(e.response.data) : e.message
        log('[AI] ' + model + ' attempt ' + attempt + ' failed (' + (status || 'no status') + '): ' + detail)
        if (status === 401) return null
        if (status === 400 || status === 403 || status === 404) { badModels.set(model, Date.now()); break }
        await sleep(status === 429 ? 2500 : 1200)
      }
    }
  }
  return null
}

async function askGroqAI(promptText, username = '', mode = 'normal') {
  let reply
  try {
    const question = String(promptText || '').trim()
    if (mode !== 'roast') {
      if (FAVORITE_QUESTION_REGEX.test(question)) reply = getFavoriteAnswer()
      else if (WHO_AM_I_REGEX.test(question)) reply = await answerWhoAmI(username)
      else if (CREATOR_REGEX.test(question)) reply = CREATOR_ANSWER
      else if (JOKE_REGEX.test(question)) mode = 'joke'
      else {
        reply = await answerPlayerQuestion(question, username)
        if (!reply) reply = await answerDirectClanLookup(question)
      }
      if (!reply && mode !== 'joke') reply = findDirectAnswer(question)
    }
    if (!reply) {
      const finalQuestion = mode === 'roast' ? buildRoastQuestion(question, username || 'player') : mode === 'joke' ? buildJokeQuestion(question) : question
      reply = await callGroq(finalQuestion, mode)
      if (reply && mode === 'roast') rememberRoast(reply)
      if (reply && mode === 'joke') rememberJoke(reply)
    }
    if (!reply) {
      reply = mode === 'roast' ? pickRoast() : mode === 'joke' ? pickJoke() : mode === 'boss' ? 'Yes boss, understood.' : 'My brain is lagging right now, ask again in a few seconds.'
    }
  } catch (e) { log('[AI] Unexpected error: ' + (e && e.message)); reply = 'My brain is lagging right now, ask again in a few seconds.' }
  reply = reply.replace(/\\s+/g, ' ').trim().slice(0, 225)
  return username ? reply + ' - ' + username : reply
}

function onAiCooldown(key, ms = AI_COOLDOWN_MS) {
  const now = Date.now()
  const last = aiLastUse.get(key) || 0
  if (now - last < ms) return true
  aiLastUse.set(key, now)
  return false
}

function findRegistrantByMcName(name) {
  const wanted = String(name || '').toLowerCase()
  if (!wanted) return null
  for (const [discordId, mcName] of Object.entries(registrations)) { if (String(mcName).toLowerCase() === wanted) return discordId }
  return null
}

function registerPlayer(discordId, mcName) {
  if (!MC_NAME_REGEX.test(mcName)) return { ok: false, error: 'invalid' }
  const owner = findRegistrantByMcName(mcName)
  if (owner && owner !== discordId) return { ok: false, error: 'taken' }
  const previous = registrations[discordId] || null
  registrations[discordId] = mcName
  saveData()
  return { ok: true, previous }
}

function parseOrderArgs(args) {
  let [a, b] = args
  if (a !== undefined && /^\\d+$/.test(a) && b !== undefined && !/^\\d+$/.test(b)) [a, b] = [b, a]
  return { kitInput: a, amountInput: b }
}

async function processOrder({ discordId, mcName, kitInput, amountInput, replyFn, source, tag = '' }) {
  const b = text => (source === 'discord' ? '**' + text + '**' : String(text))
  const kit = String(kitInput || '').toUpperCase()
  if (!kit || !KIT_RULES[kit]) { await replyFn(tag + 'Invalid kit! Available: ' + listKitNames()); return }
  const amount = amountInput === undefined ? 1 : Number(amountInput)
  if (!Number.isInteger(amount) || amount < 1 || amount > 10) { await replyFn(tag + 'Amount must be a whole number from 1 to 10.'); return }
  if (!bot || !minecraftOnline) { await replyFn(tag + 'The Minecraft bot is offline right now, try again later.'); return }
  if (busy) { await replyFn(tag + 'The bot is busy with another order, try again in a moment.'); return }
  const costPerItem = KIT_RULES[kit].cost || 3
  const totalCost = costPerItem * amount
  if (userBalances[discordId] === undefined) userBalances[discordId] = 2
  const balance = userBalances[discordId]
  if (balance < totalCost) {
    const hint = source === 'discord' ? 'Earn more with `.claim` in <#' + DAILY_CHANNEL_ID + '>.' : 'Earn more coins with .claim in the BlackCat Discord.'
    await replyFn(tag + 'Not enough Cat Coins! You need ' + b(totalCost) + ' but you have ' + b(balance) + '. ' + hint)
    return
  }
  userBalances[discordId] -= totalCost
  saveData()
  await replyFn(tag + 'Order received! Took ' + b(totalCost + ' coins') + ' from your Discord balance. New balance: ' + b(userBalances[discordId]) + '. Delivering ' + b(amount + 'x ' + kit) + ' to ' + b(mcName) + '...')
  const delivered = Number(await handleKitDelivery(mcName, kit, amount, replyFn)) || 0
  if (delivered < amount) {
    const refund = (amount - delivered) * costPerItem
    userBalances[discordId] += refund
    saveData()
    await replyFn(tag + 'Refunded ' + b(refund + ' coins') + ' for kits that were not delivered. New balance: ' + b(userBalances[discordId]) + '.')
  }
  if (source === 'game') {
    try {
      const channel = await discordClient.channels.fetch(ECONOMY_CHANNEL_ID)
      if (channel) await channel.send('🧾 In-game order by **' + mcName + '** (<@' + discordId + '>): ' + amount + 'x ' + kit + ', delivered **' + delivered + '**.')
    } catch (e) { log('Order log error: ' + e.message) }
  }
}

function transferCoins(fromId, toId, amount) {
  if (!Number.isSafeInteger(amount) || amount < 1) return { ok: false, error: 'amount' }
  if (fromId === toId) return { ok: false, error: 'self' }
  if (userBalances[fromId] === undefined) userBalances[fromId] = 2
  if (userBalances[toId] === undefined) userBalances[toId] = 2
  if (userBalances[fromId] < amount) return { ok: false, error: 'funds', balance: userBalances[fromId] }
  userBalances[fromId] -= amount
  userBalances[toId] += amount
  saveData()
  return { ok: true, fromBalance: userBalances[fromId], toBalance: userBalances[toId] }
}

function setBusy() {
  busy = true
  if (busyTimeout) clearTimeout(busyTimeout)
  busyTimeout = setTimeout(() => { if (busy) { log('[BUSY] Auto-released after 3 min timeout'); busy = false } }, 180000)
}

function clearBusy() {
  busy = false
  if (busyTimeout) { clearTimeout(busyTimeout); busyTimeout = null }
}

async function sendToDiscord(content) {
  if (!DISCORD_WEBHOOK || DISCORD_WEBHOOK.includes('PASTE_')) return
  try { await axios.post(DISCORD_WEBHOOK, { content, allowed_mentions: { parse: [] } }) } catch (e) { log('Discord webhook error: ' + e.message) }
}

async function notifyOwnerOnline() {
  if (!minecraftOnline) return
  const now = Date.now()
  if (now - lastOnlineNoticeAt < 3600000) return
  try {
    if (!discordClient.isReady()) { setTimeout(notifyOwnerOnline, 5000); return }
    const user = await discordClient.users.fetch(OWNER_ID)
    if (!user) return
    await user.send('Minecraft bot is online and ready!')
    lastOnlineNoticeAt = now
    log('Online status DM sent to owner (next allowed in 1h)')
  } catch (e) { log('Online DM error: ' + e.message) }
}

discordClient.once(Events.ClientReady, client => {
  log('Discord bot logged in as: ' + client.user.tag)
  for (const guild of client.guilds.cache.values()) {
    verificationSystem.registerCommands(guild).catch(error => log('[Commands] Sync error for ' + guild.name + ': ' + error.message))
  }
})

discordClient.on(Events.InteractionCreate, interaction => {
  verificationSystem.onInteraction(interaction).catch(error => log('[Verification] Interaction dispatch error: ' + error.message))
})

discordClient.on(Events.GuildMemberAdd, member => {
  verificationSystem.onMemberJoin(member).catch(error => log('[Verification] Member join handler error: ' + error.message))
})

function getDimensionName() {
  const dim = bot && bot.game && bot.game.dimension
  if (!dim) return 'Unknown'
  if (dim.includes('overworld')) return 'Overworld'
  if (dim.includes('nether')) return 'Nether'
  if (dim.includes('end')) return 'End'
  return dim
}

function resetTPState() {
  try { safeChat('/tpcancel'); safeChat('/tpacancel'); safeChat('/spawn') } catch {}
}

async function handleTpRequest(msg) {
  const m = msg.toLowerCase()
  const requestingUser = ['6b6tmalware', 'meseju', 'godmahfuz'].find(name => new RegExp('\\b' + name + '\\b').test(m))
  const isExactTpRequest = requestingUser && (
    m.includes('wants to teleport to you') ||
    m.includes('requested to teleport') ||
    m.includes('type /tpy')
  )
  if (isExactTpRequest) {
    const now = Date.now()
    if (now - lastTpAcceptTime < 20000) return
    lastTpAcceptTime = now
    log('Detected exact TPA request from ' + requestingUser + '. Accepting in 4 seconds...')
    await sleep(4000)
    safeChat('/tpy ' + requestingUser)
    log('Auto /tpy sent successfully for ' + requestingUser)
  }
}

function waitForTeleportCountdown() {
  return new Promise(resolve => {
    let timer = null
    function finish(result) {
      bot.removeListener('messagestr', onMsg)
      if (timer) clearTimeout(timer)
      resolve(result)
    }
    function onMsg(msg) {
      const m = msg.toLowerCase()
      if (m.includes('teleporting in')) {
        const match = msg.match(/in (\\d+) seconds/i)
        const waitTime = match ? parseInt(match[1]) * 1000 : 15000
        finish({ success: true, waitTime })
        return
      }
      if (m.includes('teleported to destination!')) finish({ success: true, waitTime: 0 })
    }
    bot.on('messagestr', onMsg)
    timer = setTimeout(() => finish({ success: false, waitTime: 0 }), TP_ACCEPT_TIMEOUT_MS)
  })
}

function getVerifiedMinecraftMapping(username) {
  if (!discordClient.isReady()) throw new Error('Discord is not connected')
  const matches = []
  for (const guild of discordClient.guilds.cache.values()) {
    const config = verificationSystem.store.getConfig(guild.id)
    if (!config) continue
    const verification = verificationSystem.store.getVerificationByIgn(guild.id, username)
    if (verification) matches.push({ guild, config, verification })
  }
  if (matches.length !== 1) {
    return { ok: false, reason: matches.length ? 'ambiguous_mapping' : 'not_linked' }
  }
  const match = matches[0]
  if (match.verification.status !== 'verified' ||
      match.verification.ign.toLowerCase() !== username.toLowerCase()) {
    return { ok: false, reason: 'not_verified' }
  }
  return { ok: true, ...match }
}

async function verifyMinecraftPlayer(username, expectedUserId = null, expectedGuildId = null) {
  const mapping = getVerifiedMinecraftMapping(username)
  if (!mapping.ok) return mapping
  const userId = mapping.verification.user_id
  if ((expectedUserId && userId !== expectedUserId) ||
      (expectedGuildId && mapping.guild.id !== expectedGuildId)) {
    return { ok: false, reason: 'mapping_changed' }
  }
  const member = await mapping.guild.members.fetch({ user: userId, force: true })
  if (!member.roles.cache.has(mapping.config.verified_role_id)) {
    return { ok: false, reason: 'verified_role_missing' }
  }
  return { ...mapping, userId }
}

function inventoryItemCount(type, name) {
  return bot.inventory.items()
    .filter(item => item.type === type && item.name === name)
    .reduce((count, item) => count + item.count, 0)
}

function isNearMinecraftPlayer(username, maxDistance = 8) {
  if (!bot || !bot.entity) return false
  const recipient = Object.values(bot.players || {}).find(player =>
    player && player.username && player.username.toLowerCase() === username.toLowerCase() && player.entity
  )
  return Boolean(recipient && bot.entity.position.distanceTo(recipient.entity.position) <= maxDistance)
}

async function takeOneClaimShulker(kitName) {
  return findAndWithdrawKitShulker({
    bot,
    kitName,
    kitRules: KIT_RULES,
    searchRadius: VIPER_CLAIM_SEARCH_RADIUS_BLOCKS,
    goals,
    log,
    sleep
  })
}

function waitForRecipientTeleport(recipientUsername, startPosition, sendRequest) {
  const activeBot = bot
  return new Promise(resolve => {
    let timer = null
    let arrivalTimer = null
    let arrivalPoll = null
    let settled = false
    const recipientKey = recipientUsername.toLowerCase()
    function finish(result) {
      if (settled) return
      settled = true
      activeBot.removeListener('messagestr', onMessage)
      if (timer) clearTimeout(timer)
      if (arrivalTimer) clearTimeout(arrivalTimer)
      if (arrivalPoll) clearInterval(arrivalPoll)
      resolve(result)
    }
    function confirmPosition() {
      if (bot !== activeBot) return false
      const recipient = Object.values(activeBot.players || {}).find(player =>
        player && player.username && player.username.toLowerCase() === recipientKey && player.entity
      )
      if (!recipient || !activeBot.entity) return false
      const moved = activeBot.entity.position.distanceTo(startPosition) > 2
      const nearRecipient = activeBot.entity.position.distanceTo(recipient.entity.position) <= 8
      return nearRecipient && moved
    }
    function waitForArrival() {
      if (arrivalPoll || settled) return
      if (timer) clearTimeout(timer)
      timer = null
      log('[CLAIM] TPA acceptance/countdown detected for ' + recipientUsername + '; checking actual position.')
      arrivalPoll = setInterval(() => {
        if (confirmPosition()) finish({ success: true })
      }, 250)
      arrivalTimer = setTimeout(() => {
        finish({ success: false, reason: 'teleport_not_confirmed' })
      }, 15000)
      if (confirmPosition()) finish({ success: true })
    }
    function onMessage(message) {
      const rawText = String(message || '')
      const response = parseTpaResponse(rawText)
      if (!response) return
      log('[CLAIM] TPA server response: ' + rawText.slice(0, 180))
      if (response.type === 'rejected') {
        finish({ success: false, reason: 'request_rejected' })
        return
      }
      if (response.type === 'accepted') {
        waitForArrival()
        return
      }
      if (response.type === 'countdown') {
        if (timer) clearTimeout(timer)
        timer = null
        if (arrivalTimer) clearTimeout(arrivalTimer)
        if (arrivalPoll) clearInterval(arrivalPoll)
        arrivalPoll = null
        const delay = (response.seconds + 1) * 1000
        log('[CLAIM] TPA countdown received (' + response.seconds + ' seconds); waiting for arrival.')
        arrivalTimer = setTimeout(waitForArrival, delay)
        return
      }
    }
    activeBot.on('messagestr', onMessage)
    timer = setTimeout(() => finish({ success: false, reason: 'timeout' }), TP_ACCEPT_TIMEOUT_MS + 20000)
    try {
      sendRequest()
    } catch (error) {
      finish({ success: false, reason: 'send_failed', error: error.message })
    }
  })
}

function sendViperTpaRequest(username) {
  if (!bot || !bot._client || bot._client.state !== 'play' || awaitingLogin) {
    throw new Error('Minecraft chat is not ready to send the TPA command.')
  }
  const command = '/tpa ' + username
  try {
    bot.chat(command)
    log('[CLAIM] Sent Minecraft command: ' + command)
  } catch (error) {
    log('[CLAIM] Could not send TPA command to ' + username + ': ' + error.message)
    throw error
  }
}

async function deliverViperClaim(username, replyFn) {
  const lowerUsername = String(username || '').toLowerCase()
  if (!MC_NAME_REGEX.test(String(username || ''))) {
    await replyFn(UNVERIFIED_CLAIM_MESSAGE)
    return
  }
  let mapping
  try {
    mapping = await verifyMinecraftPlayer(username)
  } catch (error) {
    log('[CLAIM] Verification could not be confirmed for ' + username + ': ' + error.message)
    await replyFn(UNVERIFIED_CLAIM_MESSAGE)
    return
  }
  if (!mapping.ok) {
    log('[CLAIM] Verification rejected for ' + username + ': ' + mapping.reason)
    await replyFn(UNVERIFIED_CLAIM_MESSAGE)
    return
  }
  if (!bot || !minecraftOnline) {
    await replyFn('The Minecraft connection cannot process this claim right now.')
    return
  }
  if (!KIT_RULES[VIPER_CLAIM_KIT]) {
    log('[CLAIM] Configured claim kit is not present in KIT_RULES: ' + VIPER_CLAIM_KIT)
    await replyFn('Kit claims are temporarily unavailable. Please contact an administrator.')
    return
  }
  if (busy || viperClaimDeliveryRunning) {
    await replyFn('A kit delivery is already in progress. Please try again shortly.')
    return
  }

  viperClaimDeliveryRunning = true
  setBusy()
  let reservationCreated = false
  let itemWithdrawn = false
  let deliveryRecordSaved = false
  let itemInfo = null
  function releaseReservationIfShulkerRetained(reason) {
    if (!reservationCreated || !itemWithdrawn || !itemInfo || deliveryRecordSaved) return false
    const heldCount = inventoryItemCount(itemInfo.type, itemInfo.name)
    if (heldCount !== itemInfo.baselineCount + 1) {
      log('[CLAIM] Keeping reservation after ' + reason + ': expected held Shulker count ' +
        (itemInfo.baselineCount + 1) + ', found ' + heldCount + '.')
      return false
    }
    try {
      const released = verificationSystem.store.releaseKitDelivery(mapping.guild.id, mapping.userId, VIPER_CLAIM_KIT)
      if (released) {
        reservationCreated = false
        log('[CLAIM] Released uncompleted reservation after ' + reason + '; Shulker remains in bot inventory.')
        return true
      }
      log('[CLAIM] Could not release reservation after ' + reason + ': no pending reservation found.')
    } catch (error) {
      log('[CLAIM] Could not release reservation after ' + reason + ': ' + error.message)
    }
    return false
  }
  try {
    log('[CLAIM] Verification passed for ' + username + '; attempting to reserve ' + VIPER_CLAIM_KIT + '.')
    const reserved = verificationSystem.store.reserveKitDelivery(
      mapping.guild.id, mapping.userId, mapping.verification.ign, VIPER_CLAIM_KIT
    )
    if (!reserved.ok) {
      log('[CLAIM] Claim reservation rejected for ' + username + ': ' + reserved.error)
      const messages = {
        already_claimed: '❌ You have already claimed this kit.',
        unavailable: 'This kit is not configured or is currently unavailable. Please contact an administrator.',
        limit_reached: 'The claim limit for this kit has been reached.',
        delivery_in_progress: '❌ A previous delivery is still pending. An administrator must check the bot inventory for the kit before clearing this lock; please do not retry yet.'
      }
      await replyFn(messages[reserved.error] || UNVERIFIED_CLAIM_MESSAGE)
      return
    }
    reservationCreated = true
    log('[CLAIM] Claim reservation created for ' + username + '; checking live Minecraft player.')

    const senderEntity = Object.values(bot.players || {}).find(candidate =>
      candidate && candidate.username && candidate.username.toLowerCase() === lowerUsername && candidate.entity
    )
    log('[CLAIM] Received live Minecraft chat command from ' + username +
      (senderEntity ? ' with a loaded player entity' : ' without a currently loaded player entity') +
      '; starting storage search. TPA and recipient proximity will be confirmed before delivery.')
    const takeResult = await takeOneClaimShulker(VIPER_CLAIM_KIT)
    if (!takeResult.ok) {
      if (!takeResult.reservationMustRemain) {
        verificationSystem.store.releaseKitDelivery(mapping.guild.id, mapping.userId, VIPER_CLAIM_KIT)
        reservationCreated = false
      }
      log('[CLAIM] Could not obtain one ' + VIPER_CLAIM_KIT + ' shulker for ' + username + ': ' + takeResult.reason)
      const failureMessages = {
        no_chest: 'I could not find any nearby chests or barrels. Please contact an administrator.',
        no_storage_blocks_in_registry: 'This Minecraft version does not expose supported chest storage to the bot. Please contact an administrator.',
        not_found: 'I checked nearby chests and barrels but could not find the designated kit Shulker Box.',
        invalid_kit_rule: 'The configured kit does not match a Shulker Box in this Minecraft version. Please contact an administrator.',
        withdraw_failed: 'I found the kit Shulker Box but could not take it. Check that the bot inventory has space, then retry.',
        access_failed: 'I found storage but could not open it. No kit was taken; check the bot console and chest access permissions.',
        partial_access: 'I could not inspect every nearby chest. No kit was taken; check the bot console and chest access permissions.',
        access_timeout: 'I could not reach or open the nearby storage chest in time. No kit was taken; please retry or contact an administrator.'
      }
      await replyFn(takeResult.reservationMustRemain
        ? 'Delivery could not be confirmed. Your claim is locked to prevent duplicates; contact an administrator.'
        : failureMessages[takeResult.reason] || 'I could not access kit storage. No kit was taken; please contact an administrator.')
      return
    }
    itemInfo = takeResult
    itemWithdrawn = true

    const startPosition = bot.entity.position.clone()
    log('[CLAIM] Starting TPA request to ' + username + ' after confirming one shulker in inventory.')
    const teleport = await waitForRecipientTeleport(
      username,
      startPosition,
      () => sendViperTpaRequest(username)
    )
    if (!teleport.success) {
      log('[CLAIM] TPA delivery failed for ' + username + ': ' + teleport.reason)
      const retryable = releaseReservationIfShulkerRetained('TPA failure')
      const tpaFailureMessages = {
        send_failed: 'I could not send the TPA command.',
        request_rejected: 'The server rejected or expired the TPA request.',
        timeout: 'I sent a TPA request, but it was not accepted in time. Accept the request from ' +
          String(bot && bot.username || USERNAME) + ' (try /tpaccept), then run !viper claim again.',
        teleport_not_confirmed: 'The TPA was accepted, but I could not confirm that I arrived near you.'
      }
      const failureText = tpaFailureMessages[teleport.reason] || 'TPA failed (' + teleport.reason + ').'
      await replyFn(retryable
        ? failureText + ' No kit was delivered or counted; the Shulker is still held by the bot, so you can retry.'
        : failureText + ' Delivery is uncertain; your claim remains locked to prevent duplicates. Contact an administrator.')
      return
    }

    const currentMapping = await verifyMinecraftPlayer(username, mapping.userId, mapping.guild.id)
    if (!currentMapping.ok) {
      log('[CLAIM] Verification changed before delivery for ' + username + ': ' + currentMapping.reason)
      const retryable = releaseReservationIfShulkerRetained('verification change before drop')
      await replyFn(UNVERIFIED_CLAIM_MESSAGE + (retryable
        ? ' No kit was delivered or counted; retry after verification is restored.'
        : ' No kit was dropped, but delivery is uncertain; contact an administrator about the reserved claim.'))
      return
    }
    if (!isNearMinecraftPlayer(username)) {
      log('[CLAIM] Recipient moved out of delivery range after teleport for ' + username)
      const retryable = releaseReservationIfShulkerRetained('recipient left delivery range')
      await replyFn(retryable
        ? 'You moved out of delivery range. No kit was delivered or counted; the Shulker is held by the bot, so you can retry.'
        : 'You moved out of delivery range. Delivery is uncertain; your claim remains locked to prevent duplicates. Contact an administrator.')
      return
    }
    if (inventoryItemCount(itemInfo.type, itemInfo.name) !== itemInfo.baselineCount + 1) {
      log('[CLAIM] Shulker inventory changed before drop for ' + username)
      const retryable = releaseReservationIfShulkerRetained('inventory validation before drop')
      await replyFn(retryable
        ? 'No kit was delivered or counted. The Shulker is still held by the bot, so you can retry.'
        : 'Delivery could not be confirmed. Your claim is locked to prevent duplicates; contact an administrator.')
      return
    }
    const item = bot.inventory.items().find(candidate =>
      candidate.type === itemInfo.type && candidate.name === itemInfo.name && candidate.count === 1
    )
    if (!item) {
      log('[CLAIM] Could not identify the single withdrawn shulker for ' + username)
      const retryable = releaseReservationIfShulkerRetained('could not identify Shulker before drop')
      await replyFn(retryable
        ? 'No kit was delivered or counted. The Shulker is still held by the bot, so you can retry.'
        : 'Delivery could not be confirmed. Your claim is locked to prevent duplicates; contact an administrator.')
      return
    }

    log('[CLAIM] Dropping exactly one ' + item.name + ' (id=' + item.type + ', metadata=' +
      item.metadata + ') for ' + username + '.')
    await bot.transfer({
      window: bot.inventory,
      itemType: item.type,
      metadata: item.metadata,
      count: 1,
      sourceStart: item.slot,
      sourceEnd: item.slot + 1,
      destStart: -999
    })
    let droppedCount = inventoryItemCount(itemInfo.type, itemInfo.name)
    for (let attempt = 0; droppedCount !== itemInfo.baselineCount && attempt < 20; attempt++) {
      await sleep(150)
      droppedCount = inventoryItemCount(itemInfo.type, itemInfo.name)
    }
    const cursorItem = bot.inventory.selectedItem
    if (droppedCount !== itemInfo.baselineCount ||
        (cursorItem && cursorItem.type === itemInfo.type && cursorItem.name === itemInfo.name)) {
      log('[CLAIM] Shulker drop not confirmed for ' + username + ': expected inventory count ' +
        itemInfo.baselineCount + ', found ' + droppedCount +
        (cursorItem && cursorItem.type === itemInfo.type ? '; Shulker remains on cursor.' : '.'))
      const retryable = releaseReservationIfShulkerRetained('drop confirmation failure')
      await replyFn(retryable
        ? 'No kit was delivered or counted. The Shulker is still held by the bot, so you can retry.'
        : 'Delivery could not be confirmed. Your claim is locked to prevent duplicates; contact an administrator.')
      return
    }

    const completed = verificationSystem.store.completeKitDelivery(mapping.guild.id, mapping.userId, VIPER_CLAIM_KIT)
    if (!completed.ok) {
      log('[CLAIM] Shulker dropped but claim record could not be finalized for ' + username + ': ' + completed.error)
      await replyFn('Your kit was dropped, but the claim record could not be saved. Do not claim again; contact an administrator.')
      return
    }
    deliveryRecordSaved = true
    reservationCreated = false
    log('[CLAIM] Delivered one ' + VIPER_CLAIM_KIT + ' shulker to ' + username + ' (Discord ' + mapping.userId + ').')
    if (VIPER_CLAIM_KILL_ENABLED) {
      try {
        if (!bot || !bot._client || bot._client.state !== 'play' || awaitingLogin) {
          throw new Error('Minecraft connection is not ready to send the post-delivery kill command.')
        }
        bot.chat('/kill')
        log('[CLAIM] Sent /kill immediately after confirmed item drop and saved claim.')
      } catch (error) {
        log('[CLAIM] Could not send post-delivery /kill: ' + error.message)
      }
    }
  } catch (error) {
    log('[CLAIM] Delivery failed for ' + username + ': ' + error.message)
    const retryable = releaseReservationIfShulkerRetained('delivery error')
    if (reservationCreated && !itemWithdrawn && mapping) {
      try {
        verificationSystem.store.releaseKitDelivery(mapping.guild.id, mapping.userId, VIPER_CLAIM_KIT)
        reservationCreated = false
      } catch (releaseError) {
        log('[CLAIM] Could not release safe pre-delivery reservation: ' + releaseError.message)
      }
    }
    if (itemWithdrawn && !deliveryRecordSaved && retryable) {
      await replyFn('No kit was delivered or counted. The Shulker is still held by the bot, so you can retry.')
    } else if (itemWithdrawn && !deliveryRecordSaved) {
      await replyFn('Delivery could not be confirmed. Your claim is locked to prevent duplicate items; contact an administrator.')
    } else {
      await replyFn('Kit delivery failed safely. Please contact an administrator.')
    }
  } finally {
    viperClaimDeliveryRunning = false
    clearBusy()
  }
}

function shulkerMatchesKit(item, kitName) {
  return bot && matchesKitShulker(item, kitName, KIT_RULES, bot.registry.itemsByName)
}

async function getKitShulker(kitName, amount) {
  const chestPositions = bot.findBlocks({
    matching: b => b && (b.name.includes('chest') || b.name.includes('trapped_chest') || b.name.includes('barrel')),
    maxDistance: 32,
    count: 25
  })
  if (!chestPositions || chestPositions.length === 0) return { success: false, reason: 'no_chest' }
  let takenCount = 0
  for (const pos of chestPositions) {
    if (takenCount >= amount) break
    const chestBlock = bot.blockAt(pos)
    if (!chestBlock) continue
    let container = null
    try {
      const d = bot.entity.position.distanceTo(chestBlock.position)
      if (d > 2) {
        await bot.pathfinder.goto(new goals.GoalNear(chestBlock.position.x, chestBlock.position.y, chestBlock.position.z, 1.5))
        await sleep(300)
      }
      container = await bot.openContainer(chestBlock)
      await sleep(500)
      const inventoryStart = typeof container.inventoryStart === 'number' ? container.inventoryStart : container.slots.length
      for (let slot = 0; slot < inventoryStart; slot++) {
        if (takenCount >= amount) break
        const item = container.slots[slot]
        if (item && shulkerMatchesKit(item, kitName)) {
          try {
            await container.withdraw(item.type, null, 1)
            takenCount++
            await sleep(400)
          } catch {
            try { await container.click(slot, 0, 0); takenCount++; await sleep(400) } catch {}
          }
        }
      }
      try { container.close() } catch {}
      await sleep(300)
    } catch (e) {
      log('[CHEST] Error: ' + e.message)
      try { if (container) container.close() } catch {}
    }
  }
  if (takenCount === 0) return { success: false, reason: 'not_found' }
  return { success: true, taken: takenCount }
}

async function handleKitDelivery(deliverUsername, kitName, amount, replyFn, isGiveaway = false, issuerName = '') {
  if (busy || viperClaimDeliveryRunning) { await replyFn('Bot is busy right now, try again in a moment.'); return 0 }
  setBusy()
  let delivered = 0
  try {
    const result = await getKitShulker(kitName, amount)
    if (!result.success) {
      const reasons = { no_chest: 'No chests found nearby', not_found: 'Matching shulkers not found', withdraw_failed: 'Withdraw failed' }
      await replyFn(reasons[result.reason] || 'Items not found')
      return 0
    }
    const taken = result.taken
    safeChat('/tpa ' + deliverUsername)
    const tp = await waitForTeleportCountdown()
    if (!tp.success) {
      await replyFn(deliverUsername + ' did not accept TP or teleport failed.')
      resetTPState()
      return 0
    }
    if (tp.waitTime > 0) await sleep(tp.waitTime + 2000)
    const items = bot.inventory.items()
    for (const item of items) { try { await bot.tossStack(item); await sleep(300) } catch {} }
    await sleep(9000)
    safeChat('/kill')
    await replyFn(taken + 'x ' + kitName + ' delivered to ' + deliverUsername + '!')
    delivered = taken
    if (isGiveaway) {
      try {
        const economyChannel = await discordClient.channels.fetch(ECONOMY_CHANNEL_ID)
        if (economyChannel) await economyChannel.send('🎁 **GIVEAWAY LOG:** `' + kitName + '` kit giveaway by **' + issuerName + '** to **' + deliverUsername + '** (Amount: **' + taken + '**)!')
      } catch {}
    }
    resetTPState()
  } catch (e) {
    await replyFn('Unexpected error: ' + e.message)
    resetTPState()
  } finally { clearBusy() }
  return delivered
}

async function handleBedCommand(replyFn, maxDistance = 16, sleepAtNight = true) {
  if (bedCommandRunning) { await replyFn('Already setting a respawn point. Please wait.'); return }
  bedCommandRunning = true
  try {
    const bedBlock = bot.findBlocks({ matching: b => b && b.name.includes('bed'), maxDistance, count: 1 })
    if (!bedBlock || bedBlock.length === 0) { await replyFn('No bed found nearby!'); return }
    const targetBed = bot.blockAt(bedBlock[0])
    const goal = new goals.GoalNear(targetBed.position.x, targetBed.position.y, targetBed.position.z, 2)
    bot.pathfinder.stop()
    try {
      await bot.pathfinder.goto(goal)
    } catch (e) {
      if (!String(e && e.message || e).toLowerCase().includes('goal was changed')) throw e
      bot.pathfinder.stop()
      await sleep(300)
      await bot.pathfinder.goto(goal)
    }
    await sleep(500)
    const currentBed = bot.blockAt(bedBlock[0])
    if (!currentBed || !currentBed.name.includes('bed')) { await replyFn('The nearby bed is no longer available.'); return }
    await bot.activateBlock(currentBed)
    await replyFn('Activated the bed. Check the server message to confirm your respawn point was set.')
    const time = bot.time.timeOfDay
    if (sleepAtNight && time >= 12500 && time < 23460) {
      await sleep(4000)
      try { await bot.wake(); await replyFn('Slept and left the bed.') } catch {}
    }
  } catch (e) { await replyFn('Bed error: ' + e.message) }
  finally { bedCommandRunning = false }
}

async function handleViperRespawn(username, replyFn) {
  if (String(username || '').toLowerCase() !== VIPER_RESPAWN_AUTHORIZED_USERNAME.toLowerCase()) {
    await replyFn('❌ Only ' + VIPER_RESPAWN_AUTHORIZED_USERNAME + ' can use this command.')
    return
  }
  if (!bot || !minecraftOnline || typeof bot.findBlocks !== 'function') {
    await replyFn('The Minecraft connection is offline. No respawn change was made.')
    return
  }
  const player = Object.values(bot && bot.players || {}).find(candidate =>
    candidate && candidate.username && candidate.username.toLowerCase() === username.toLowerCase() && candidate.entity
  )
  if (!player) {
    await replyFn('I cannot locate your player position right now. No respawn change was made.')
    return
  }
  if (bedCommandRunning) {
    await replyFn('Already setting a respawn point. Please wait.')
    return
  }
  bedCommandRunning = true
  try {
    const bedPositions = bot.findBlocks({
      matching: block => block && (block.name === 'bed' || block.name.endsWith('_bed')),
      point: player.entity.position,
      maxDistance: VIPER_RESPAWN_RADIUS_BLOCKS,
      count: 50
    })
    const bedBlock = (bedPositions || []).map(position => bot.blockAt(position)).find(block => {
      if (!block || (block.name !== 'bed' && !block.name.endsWith('_bed')) ||
          block.position.distanceTo(player.entity.position) > VIPER_RESPAWN_RADIUS_BLOCKS) return false
      return [
        block.position.offset(1, 0, 0),
        block.position.offset(-1, 0, 0),
        block.position.offset(0, 0, 1),
        block.position.offset(0, 0, -1)
      ].some(position => {
        const neighbor = bot.blockAt(position)
        return neighbor && neighbor.name === block.name
      })
    })
    if (!bedBlock) {
      await replyFn('A valid bed must be placed within ' + VIPER_RESPAWN_RADIUS_BLOCKS + ' blocks of you.')
      return
    }

    const activeBot = bot
    try {
      const goal = new goals.GoalNear(bedBlock.position.x, bedBlock.position.y, bedBlock.position.z, 2)
      activeBot.pathfinder.stop()
      await activeBot.pathfinder.goto(goal)
      await sleep(300)
      const currentBed = activeBot.blockAt(bedBlock.position)
      if (!currentBed || currentBed.name !== bedBlock.name) {
        await replyFn('The bed is no longer available. No respawn change was made.')
        return
      }

      let finishConfirmation
      const confirmation = new Promise(resolve => {
        let settled = false
        const timer = setTimeout(() => finish({ confirmed: false }), 4000)
        function finish(result) {
          if (settled) return
          settled = true
          clearTimeout(timer)
          activeBot.removeListener('messagestr', onMessage)
          resolve(result)
        }
        function onMessage(message) {
          const text = String(message || '')
          if (/respawn point set|spawn point set/i.test(text)) {
            finish({ confirmed: true })
          } else if (/you may not rest now|bed is occupied|not a safe place|cannot set.*spawn/i.test(text)) {
            finish({ confirmed: false, rejected: true })
          }
        }
        finishConfirmation = finish
        activeBot.on('messagestr', onMessage)
      })
      try {
        await activeBot.activateBlock(currentBed)
      } catch (error) {
        finishConfirmation({ confirmed: false, rejected: true })
        throw error
      }
      const result = await confirmation
      if (result.confirmed) {
        await replyFn('✅ Respawn point set for the bot at the nearby bed.')
      } else {
        await replyFn('The bed was activated, but the server did not confirm a respawn point change.')
      }
    } catch (error) {
      log('[RESPAWN] Could not set bot respawn at bed: ' + error.message)
      await replyFn('Could not reach or activate the bed. No respawn change was confirmed.')
    }
  } finally {
    bedCommandRunning = false
  }
}

function guardClient(c) {
  c.setMaxListeners(100)
  const emit = c.emit
  c.emit = function (event, ...args) {
    const listeners = this.rawListeners(event)
    if (listeners.length === 0) return emit.call(this, event, ...args)
    for (const listener of listeners) {
      try { listener.apply(this, args) } catch (e) {
        const msg = e && e.message ? e.message : String(e)
        if (!isIgnorableError(msg)) log('(protocol) listener error on "' + String(event) + '": ' + msg)
      }
    }
    return true
  }
  const write = c.write.bind(c)
  c.write = function (name, params) {
    const n = String(name)
    if ((c.state === 'configuration' && !CONFIGURATION_SERVERBOUND.has(n)) || (awaitingLogin && c.state === 'play' && MOVEMENT.has(n))) {
      if (!dropped.has(n)) { dropped.add(n); log('(protocol) held back "' + n + '"') }
      return false
    }
    return write(name, params)
  }
  c.on('cookie_request', (p) => { try { write('cookie_response', { key: p.cookie }) } catch {} })
  c.on('add_resource_pack', (p) => {
    try { write('resource_pack_receive', { uuid: p.uuid, result: 3 }); write('resource_pack_receive', { uuid: p.uuid, result: 0 }) } catch {}
  })
  c.on('start_configuration', () => { awaitingLogin = false; dropped = new Set(); try { bot.clearControlStates() } catch {} ; try { bot.physicsEnabled = false } catch {} })
  c.on('finish_configuration', () => { awaitingLogin = true })
}

function guardRegistry(b) {
  const reg = b.registry
  if (!reg || typeof reg.loadDimensionCodec !== 'function') return
  const load = reg.loadDimensionCodec.bind(reg)
  reg.loadDimensionCodec = (codec) => {
    try {
      if (codec && Array.isArray(codec.entries) && codec.entries.some(e => !e || e.value == null)) {
        const id = String(codec.id || '')
        codec = { ...codec, entries: codec.entries.map(e => {
          if (e && e.value != null) return e
          const dim = id.endsWith('dimension_type') && VANILLA_DIMENSIONS[e && e.key]
          const value = dim ? { min_y: { type: 'int', value: dim[0] }, height: { type: 'int', value: dim[1] } } : {}
          return { key: e && e.key, value: { type: 'compound', name: '', value } }
        }) }
      }
      return load(codec)
    } catch (e) { log('(protocol) registry load issue: ' + (e && e.message)) }
  }
}

async function walkForwardDistance(blocksToWalk, maxTimeMs = 20000) {
  if (!bot || !bot.entity) return
  bot.physicsEnabled = true
  const startPos = bot.entity.position.clone()
  bot.setControlState('forward', true)
  const startTime = Date.now()
  while (Date.now() - startTime < maxTimeMs) {
    if (!bot || !bot.entity) break
    if (startPos.distanceTo(bot.entity.position) >= blocksToWalk) break
    await sleep(50)
  }
  if (bot) bot.setControlState('forward', false)
}

async function handleInGameChat(username, message) {
  const rawText = message.trim()
  const lowerText = rawText.toLowerCase()
  const viperAiCommand = parseViperAiCommand(rawText)
  if (viperAiCommand) {
    if (!viperAiCommand.question) {
      safeChat('/msg ' + username + ' Usage: !viper ai <question> (example: !viper ai What is Minecraft?)')
      return
    }
    const result = await geminiAi.answer(username, viperAiCommand.question)
    if (result.ok) {
      for (const chatMessage of formatMinecraftMessages(result.chunks)) safeChat(chatMessage)
    } else if (result.error === 'cooldown') {
      safeChat('/msg ' + username + ' Please wait ' + result.retryAfterSeconds + ' seconds before asking Gemini again.')
    } else if (result.error === 'in_progress') {
      safeChat('/msg ' + username + ' Your previous Gemini question is still being answered.')
    } else if (result.error === 'missing_key') {
      safeChat('/msg ' + username + ' Gemini AI is not configured yet. Please contact an administrator.')
    } else if (result.error === 'rate_limited') {
      safeChat('/msg ' + username + ' Gemini is rate-limited right now. Please try again shortly.')
    } else if (result.error === 'timeout') {
      safeChat('/msg ' + username + ' Gemini took too long to respond. Please try again.')
    } else if (result.error === 'empty_response') {
      safeChat('/msg ' + username + ' Gemini returned no answer. Please rephrase and try again.')
    } else if (result.error === 'invalid_api_key') {
      log('[Gemini] API rejected the configured key (HTTP 401).' + (result.providerMessage ? ' ' + result.providerMessage : ''))
      safeChat('/msg ' + username + ' Gemini setup error: the API key was rejected. Please contact an administrator.')
    } else if (result.error === 'access_denied') {
      log('[Gemini] API access denied for the configured project or model (HTTP 403).' + (result.providerMessage ? ' ' + result.providerMessage : ''))
      safeChat('/msg ' + username + ' Gemini setup error: API or model access is denied. Please contact an administrator.')
    } else if (result.error === 'model_not_found') {
      log('[Gemini] Configured model was not found for this API (HTTP 404).' + (result.providerMessage ? ' ' + result.providerMessage : ''))
      safeChat('/msg ' + username + ' Gemini setup error: the configured model is unavailable. Please contact an administrator.')
    } else if (result.error === 'invalid_request') {
      log('[Gemini] API rejected the request configuration (HTTP 400).')
      safeChat('/msg ' + username + ' Gemini could not process that request. Please rephrase it or contact an administrator.')
    } else if (result.error === 'service_unavailable') {
      log('[Gemini] API service failed (HTTP ' + result.status + ').' + (result.providerMessage ? ' ' + result.providerMessage : ''))
      safeChat('/msg ' + username + ' Gemini is temporarily unavailable. Please try again later.')
    } else {
      const providerMessage = result.providerMessage ? ' ' + result.providerMessage : ''
      if (result.status) log('[Gemini] Request failed: ' + result.error + ' (HTTP ' + result.status + ').' + providerMessage)
      else log('[Gemini] Request failed: ' + result.error + providerMessage)
      safeChat('/msg ' + username + ' Gemini is unavailable right now. Please try again later.')
    }
    return
  }
  if (/^!viper\s+claim$/i.test(rawText)) {
    await deliverViperClaim(username, text => safeChat('/msg ' + username + ' ' + text, { preserveUrls: true }))
    return
  }
  if (/^!viper\s+set\s+(?:resspwan|respawn)$/i.test(rawText)) {
    await handleViperRespawn(username, text => safeChat('/msg ' + username + ' ' + text))
    return
  }
  const isOwner = IN_GAME_OWNERS.includes(username.toLowerCase())
  updateFavoritePerson(username, rawText)
  autoRoastWatcher(username, rawText, isOwner).catch(e => log('Auto-roast error: ' + (e && e.message)))
  if (username.toLowerCase() === 'godmahfuz') {
    if (/^!viper\s+tpa$/i.test(rawText)) {
      safeChat('/tpa GodMahfuz')
      return
    }
  }
  if (isOwner) {
    const gk = rawText.match(GIVE_KIT_REGEX)
    if (gk) {
      if (!bot.players[username]) return
      let amount = gk[1] ? parseInt(gk[1], 10) : 1
      amount = Math.min(Math.max(amount, 1), 5)
      let kit = (gk[2] || 'pvp').toUpperCase()
      if (kit === 'TOTUM') kit = 'TOTUMS'
      const target = gk[3]
      if (onAiCooldown('givekit:' + username.toLowerCase(), 5000)) return
      if (busy) { safeChat('/msg ' + username + ' Busy right now, try again in a moment.'); return }
      handleKitDelivery(target, kit, amount, (msg) => safeChat('/msg ' + username + ' ' + msg), true, username).catch(e => log('Give kit error: ' + e.message))
      sendToDiscord('🎁 **Kit Giveaway:** `' + kit + '` x' + amount + ' delivered to **' + target + '** by **' + username + '**')
      return
    }
  }
  if (/^!(kits?|coins?|catcoins?|discord|shop)$/i.test(rawText)) {
    if (!onAiCooldown('kit:' + username.toLowerCase(), 15000)) safeChat('/msg ' + username + ' ' + KIT_INFO)
    return
  }
  if (/^\^order(\s|$)/i.test(rawText)) {
    if (onAiCooldown('order:' + username.toLowerCase(), 5000)) return
    const dm = text => safeChat('/msg ' + username + ' ' + text)
    const discordId = findRegistrantByMcName(username)
    if (!discordId) { dm('You are not registered! Use /register ' + username + ' in the BlackCat Discord first.'); return }
    const args = rawText.slice(6).trim().split(/\s+/).filter(Boolean)
    if (args.length === 0) { dm('Usage: ^order <kit> <amount> (kits: ' + listKitNames() + ')'); return }
    const { kitInput, amountInput } = parseOrderArgs(args)
    await processOrder({ discordId, mcName: username, kitInput, amountInput, replyFn: async text => dm(text), source: 'game' })
    return
  }
  if (/^\^gamble(\s|$)/i.test(rawText)) {
    const dm = text => safeChat('/msg ' + username + ' ' + text)
    const discordId = findRegistrantByMcName(username)
    if (!discordId) { dm('You are not registered! Use /register ' + username + ' in the BlackCat Discord first.'); return }
    const args = rawText.replace(/^\^gamble/i, '').trim().split(/\s+/).filter(Boolean)
    if (args.length === 0 || !/^\d+$/.test(args[0])) { dm('Usage: ^gamble <amount> (min ' + GAMBLE_MIN_BET + ', max ' + GAMBLE_MAX_BET + ')'); return }
    if (onGambleCooldown(discordId)) { dm('Slow down — wait a few seconds.'); return }
    const amount = parseInt(args[0], 10)
    const result = runGamble(discordId, amount)
    if (!result.ok) {
      if (result.error === 'min') dm('Min bet ' + GAMBLE_MIN_BET + '.')
      else if (result.error === 'max') dm('Max bet ' + GAMBLE_MAX_BET + '.')
      else if (result.error === 'funds') dm('Not enough coins! Bal: ' + result.balance)
      else dm('Error placing bet.')
      return
    }
    dm(result.win ? 'YOU WIN +' + result.amount + '! ' + result.line + ' Bal: ' + result.balance : 'YOU LOSE -' + result.amount + '. ' + result.line + ' Bal: ' + result.balance)
    return
  }
  if (/^\^(pay|share)(\s|$)/i.test(rawText)) {
    if (onAiCooldown('pay:' + username.toLowerCase(), 5000)) return
    const dm = text => safeChat('/msg ' + username + ' ' + text)
    const fromId = findRegistrantByMcName(username)
    if (!fromId) { dm('You are not registered!'); return }
    const args = rawText.replace(/^\^(pay|share)/i, '').trim().split(/\s+/).filter(Boolean)
    if (args.length < 2) { dm('Usage: ^pay <player> <amount>'); return }
    const toId = findRegistrantByMcName(args[0])
    if (!toId) { dm(args[0] + ' is not registered.'); return }
    const amount = /^\d+$/.test(args[1]) ? Number(args[1]) : NaN
    const result = transferCoins(fromId, toId, amount)
    if (!result.ok) {
      dm(result.error === 'self' ? 'Cannot pay yourself.' : result.error === 'funds' ? 'Insufficient funds. Bal: ' + result.balance : 'Invalid amount.')
      return
    }
    const toName = registrations[toId]
    dm('Sent ' + amount + ' Cat Coins to ' + toName + '. Bal: ' + result.fromBalance + '.')
    safeChat('/msg ' + toName + ' You received ' + amount + ' Cat Coins from ' + username + '.')
    try {
      const channel = await discordClient.channels.fetch(ECONOMY_CHANNEL_ID)
      if (channel) await channel.send('💸 In-game transfer: **' + username + '** sent **' + amount + ' Cat Coins** to **' + toName + '** (<@' + toId + '>).')
    } catch {}
    return
  }
  const pm = rawText.match(/^!(?:player|stats?|profile)\s+([A-Za-z0-9_]{3,16})\s*$/i)
  if (pm) {
    if (onAiCooldown('mc:' + username.toLowerCase())) return
    safeChat(await askGroqAI('player ' + pm[1], username))
    return
  }
  if (lowerText.startsWith('!ai ') || lowerText === '!ai') {
    const question = rawText.slice(3).trim()
    if (!question) { safeChat('Usage: !ai <question>'); return }
    if (onAiCooldown('mc:' + username.toLowerCase())) return
    const aiAnswer = await askGroqAI(question, username, isBossName(username) ? 'boss' : isRoastWorthy(question) ? 'roast' : 'normal')
    safeChat(aiAnswer)
    return
  }
  if (rawText.startsWith('<')) {
    const prompt = rawText.slice(1).trim()
    if (!prompt) { safeChat('Usage: < <question>'); return }
    if (onAiCooldown('mc:' + username.toLowerCase())) return
    const aiAnswer = await askGroqAI(prompt, username, isBossName(username) ? 'boss' : 'normal')
    safeChat(aiAnswer)
    return
  }
  if (rawText.startsWith('~')) {
    if (!isOwner) return
    const parts = rawText.slice(1).trim().split(/\\s+/)
    const kit = parts[0] ? parts[0].toUpperCase() : null
    let amount = 1, targetUsername = null
    if (parts.length >= 3) {
      const arg1 = parts[1], arg2 = parts[2]
      if (!isNaN(parseInt(arg1))) { amount = parseInt(arg1); targetUsername = arg2 }
      else if (!isNaN(parseInt(arg2))) { amount = parseInt(arg2); targetUsername = arg1 }
      else { targetUsername = arg1 }
    } else if (parts.length === 2) {
      targetUsername = parts[1]
    }
    if (!kit || !targetUsername) { safeChat('/msg ' + username + ' Usage: ~<kit> <amount> <player>'); return }
    if (!KIT_RULES[kit]) { safeChat('/msg ' + username + ' Invalid kit!'); return }
    if (!Number.isInteger(amount) || amount < 1 || amount > 10) { safeChat('/msg ' + username + ' Amount must be 1-10.'); return }
    safeChat('/msg ' + username + ' Processing: ' + amount + 'x ' + kit + ' for ' + targetUsername + '...')
    handleKitDelivery(targetUsername, kit, amount, (msg) => safeChat('/msg ' + username + ' ' + msg), true, username).catch(e => log('Giveaway error: ' + e.message))
    return
  }
  if (lowerText === 'bed') { handleBedCommand((msg) => safeChat('/msg ' + username + ' ' + msg)); return }
  if (!isOwner) return
  if (lowerText === 'follow') {
    const targetPlayer = bot.players[username] && bot.players[username].entity
    if (!targetPlayer) { safeChat('I cannot see you.'); return }
    log('Following player: ' + username)
    safeChat('Following you!')
    bot.pathfinder.setGoal(new goals.GoalFollow(targetPlayer, 2), true)
  } else if (lowerText === 'stop' || lowerText === 'shut up') {
    if (attackInterval) { clearInterval(attackInterval); attackInterval = null }
    bot.pathfinder.stop(); bot.clearControlStates(); safeChat('Stopped.')
  } else if (lowerText === 'eat') {
    const foodItem = bot.inventory.items().find(item => item.foodPoints > 0 || /apple|carrot|bread|beef|porkchop|mutton|chicken/i.test(item.name))
    if (!foodItem) { safeChat('No food!'); return }
    try { await bot.equip(foodItem, 'hand'); await bot.consume(); safeChat('Ate ' + foodItem.name + '!') } catch (e) { safeChat('Failed to eat.') }
  } else if (lowerText.startsWith('kill ') || lowerText.startsWith('attack ')) {
    const targetName = rawText.split(/\\s+/)[1]
    if (!targetName) { safeChat('Usage: kill <player>'); return }
    const targetEntity = bot.players[targetName] && bot.players[targetName].entity
    if (!targetEntity) { safeChat('Player not found nearby.'); return }
    log('Attacking player: ' + targetName)
    safeChat('Attacking ' + targetName + '!')
    bot.pathfinder.setGoal(new goals.GoalFollow(targetEntity, 1), true)
    if (attackInterval) clearInterval(attackInterval)
    attackInterval = setInterval(() => {
      const currentTarget = bot.players[targetName] && bot.players[targetName].entity
      if (!currentTarget) { clearInterval(attackInterval); attackInterval = null; return }
      if (bot.entity.position.distanceTo(currentTarget.position) > 4) return
      try { bot.attack(currentTarget) } catch {}
    }, 500)
  }
}

async function handleServerMessage(jsonMsg, messageString) {
  if (!activeBounty) return
  const text = messageString || (jsonMsg && jsonMsg.toString()) || ''
  const lower = text.toLowerCase(), targetLower = activeBounty.target.toLowerCase()
  if (lower.includes(targetLower)) {
    const isKillMessage = lower.includes('slain by') || lower.includes('shot by') || lower.includes('blown apart by') || lower.includes('torn to shreds') || lower.includes('was killed by') || lower.includes('by magic') || lower.includes('fireballed')
    if (isKillMessage) {
      try {
        const channel = await discordClient.channels.fetch(BOUNTY_CHANNEL_ID)
        if (channel) await channel.send('🎯 **BOUNTY UPDATE!**\\n💀 **Target Down:** `' + activeBounty.target + '`\\n📄 **Death Log:** `' + text + '`\\n👑 **Reward:** `' + activeBounty.reward + '`\\n📌 Admin, verify the killer and reward them!')
      } catch {}
    }
  }
}

function createBot() {
  const host = SERVERS[serverIndex % SERVERS.length]
  log('Connecting to ' + host + ' as ' + USERNAME + '...')
  minecraftOnline = false; awaitingLogin = false; dropped = new Set()
  bot = mineflayer.createBot({ host, port: 25565, username: USERNAME, auth: 'offline', version: VERSION, physicsEnabled: false, checkTimeoutInterval: 60000, hideErrors: true, logErrors: false })
  guardClient(bot._client); guardRegistry(bot); bot.loadPlugin(pathfinder)
  bot.on('login', () => { awaitingLogin = false; log('Play login') })
  bot.on('spawn', async () => {
    const activeBot = bot
    stopPromotions()
    log('Spawned'); clearBusy(); minecraftOnline = true
    bot.inventory.on('updateSlot', scheduleDefensiveEquip)
    scheduleDefensiveEquip()
    setTimeout(notifyOwnerOnline, 7000)
    try {
      const mcData = minecraftData(bot.version)
      const move = new Movements(bot, mcData)
      bot.pathfinder.setMovements(move)
    } catch {}
    await sleep(2000)
    try { bot.physicsEnabled = true } catch {}
    await sleep(1000)
    safeChat('/login ' + PASSWORD)
    await sleep(5000)
    await walkForwardDistance(15, 15000)
    await sleep(3000)
    await walkForwardDistance(13, 10000)
    if (bot === activeBot && minecraftOnline && !awaitingLogin &&
        activeBot._client && activeBot._client.state === 'play') {
      startPromotions(activeBot)
    }
  })
  bot.on('chat', (u, msg) => {
    if (u === bot.username) return
    log('[CHAT] <' + u + '> ' + msg)
    sendToDiscord('[6b6t] <' + u + '> ' + msg)
    handleInGameChat(u, msg).catch(e => log('Chat error: ' + (e && e.message)))
  })
  bot.on('messagestr', msg => {
    log('[SERVER] ' + msg)
    handleTpRequest(msg); handleServerMessage(null, msg)
    const lower = msg.toLowerCase()
    if (lower.includes('please login') || lower.includes('/login ')) { safeChat('/login ' + PASSWORD) }
  })
  bot.on('kicked', reason => { log('[KICKED] ' + reason); stopPromotions(); clearBusy(); minecraftOnline = false })
  bot.on('end', reason => {
    log('Disconnected -> reconnecting in 15s')
    stopPromotions()
    clearBusy()
    if (attackInterval) { clearInterval(attackInterval); attackInterval = null }
    minecraftOnline = false; serverIndex++; setTimeout(createBot, 15000)
  })
  bot.on('error', err => {
    const msg = err && err.message ? err.message : String(err)
    if (isIgnorableError(msg)) return
    log('Error: ' + msg); clearBusy()
  })
}

function connectDiscord() {
  if (!DISCORD_TOKEN || DISCORD_TOKEN.includes('PASTE_')) { log('Discord token missing'); return }
  if (discordClient.isReady() || discordLoginInProgress) return
  discordLoginInProgress = true
  discordClient.login(DISCORD_TOKEN)
    .then(() => { discordLoginInProgress = false })
    .catch(err => {
      discordLoginInProgress = false
      log('Discord login error: ' + err.message)
      if (discordReconnectTimer) clearTimeout(discordReconnectTimer)
      discordReconnectTimer = setTimeout(connectDiscord, 15000)
    })
}

discordClient.on('error', err => {
  log('Discord error: ' + err.message)
  if (discordReconnectTimer) clearTimeout(discordReconnectTimer)
  discordReconnectTimer = setTimeout(connectDiscord, 15000)
})

discordClient.on('messageCreate', async message => {
  try {
    if (message.author.bot) return
    const content = message.content.trim(), lowerContent = content.toLowerCase(), userId = message.author.id
    if (message.channel.id === DISCORD_BRIDGE_CHANNEL_ID && content) {
      if (!minecraftOnline) {
        log('Discord-to-game bridge skipped: Minecraft bot is offline')
        if (/^!(msg|w)(\s|$)/i.test(content)) await message.reply('Minecraft bot is offline right now.')
        return
      }
      const relayText = content.replace(/[\r\n\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim()
      const attribution = '[Discord] ' + message.author.username + ': '
      if (/^!msg(?:\s|$)/i.test(relayText)) {
        const text = relayText.replace(/^!msg\s*/i, '').trim()
        if (!text) { await message.reply('Usage: `!msg <message>`'); return }
        safeChat((attribution + text).slice(0, 200))
        return
      }
      if (/^!w(?:\s|$)/i.test(relayText)) {
        const whisper = relayText.match(/^!w\s+([A-Za-z0-9_]{3,16})\s+(.+)$/i)
        if (!whisper) { await message.reply('Usage: `!w <player name> <whisper>`'); return }
        const commandPrefix = '/msg ' + whisper[1] + ' ' + attribution
        const text = whisper[2].slice(0, Math.max(0, 200 - commandPrefix.length))
        if (!text) { await message.reply('Please include a whisper message.'); return }
        safeChat(commandPrefix + text)
        return
      }
      const gameMessage = (attribution + relayText).slice(0, 200)
      safeChat(gameMessage)
      return
    }
    updateFavoritePerson(message.author.username, content)
    if (userBalances[userId] === undefined) { userBalances[userId] = 2; saveData() }
    if (lowerContent.startsWith('!ai ') || lowerContent === '!ai') {
      const question = content.slice(3).trim()
      if (!question) { await message.reply('⚠️ Usage: `!ai <question>`'); return }
      if (onAiCooldown('dc:' + userId)) return
      try { await message.channel.sendTyping() } catch {}
      const asker = registrations[userId] || message.author.username
      const aiAnswer = await askGroqAI(question, asker, isBossName(registrations[userId]) ? 'boss' : isRoastWorthy(question) ? 'roast' : 'normal')
      await message.reply('💬 ' + aiAnswer)
      return
    }
    if (/^[.\\/]register(\\s|$)/i.test(content)) {
      const name = content.split(/\\s+/)[1]
      if (!name) { await message.reply('⚠️ Usage: `/register <name>`'); return }
      const result = registerPlayer(userId, name)
      if (!result.ok) {
        await message.reply(result.error === 'taken' ? '❌ **' + name + '** already registered.' : '❌ Invalid MC name.')
        return
      }
      await message.reply('✅ Registered as **' + name + '**.')
      return
    }
    if (/^[.\\/]unregister(\\s|$)/i.test(content)) {
      const name = content.split(/\\s+/)[1]
      if (!name) {
        if (!registrations[userId]) { await message.reply('⚠️ Not registered.'); return }
        const old = registrations[userId]; delete registrations[userId]; saveData()
        await message.reply('✅ **' + old + '** unregistered.')
        return
      }
      if (!ADMIN_IDS.includes(userId)) { await message.reply('❌ Admin only.'); return }
      const owner = findRegistrantByMcName(name)
      if (!owner) { await message.reply('⚠️ **' + name + '** not registered.'); return }
      delete registrations[owner]; saveData()
      await message.reply('✅ **' + name + '** unregistered from <@' + owner + '>.')
      return
    }
    if (/^[.\\\\](pay|share|give|send)(\\s|$)/i.test(content)) {
      const args = content.replace(/^[.\\\\](pay|share|give|send)/i, '').trim().split(/\\s+/).filter(Boolean)
      if (args.length < 2) { await message.reply('⚠️ Usage: `\\\\pay @user <amount>`'); return }
      let who = args[0], amountText = args[1]
      if (/^\\d+$/.test(who) && !/^\\d+$/.test(amountText)) { who = args[1]; amountText = args[0] }
      let toId = null
      const ping = who.match(/^<@!?(\\d+)>$/)
      if (ping) toId = ping[1]
      else if (/^\\d{17,20}$/.test(who)) toId = who
      else {
        const plain = who.replace(/^@/, '')
        toId = findRegistrantByMcName(plain)
      }
      if (!toId) { await message.reply('❌ User not registered.'); return }
      const amount = /^\\d+$/.test(amountText) ? Number(amountText) : NaN
      const fromId = userId
      const result = transferCoins(fromId, toId, amount)
      if (!result.ok) {
        await message.reply(result.error === 'self' ? 'Cannot pay yourself.' : result.error === 'funds' ? 'Insufficient funds. Bal: ' + result.balance : 'Invalid amount.')
        return
      }
      const toName = registrations[toId]
      await message.reply('✅ Sent ' + amount + ' Cat Coins to ' + toName + '. Your balance: ' + result.fromBalance + '.')
      try {
        const channel = await discordClient.channels.fetch(ECONOMY_CHANNEL_ID)
        if (channel) await channel.send('💸 Transfer: **' + message.author.username + '** sent **' + amount + ' Cat Coins** to **' + toName + '** (<@' + toId + '>).')
      } catch {}
      return
    }
    if (lowerContent.startsWith('.claim') || lowerContent.startsWith('/claim')) {
      if (message.channel.id !== DAILY_CHANNEL_ID) { await message.reply('⚠️ Use <#' + DAILY_CHANNEL_ID + '> to claim daily coins!'); return }
      const today = new Date().toISOString().split('T')[0]
      if (lastDailyClaim[userId] === today) { await message.reply('❌ You already claimed today! Come back tomorrow.'); return }
      lastDailyClaim[userId] = today
      userBalances[userId] = (userBalances[userId] || 0) + 5
      saveData()
      await message.reply('✅ Claimed **5 Cat Coins**! New balance: **' + userBalances[userId] + '**.')
      return
    }
    if (lowerContent.startsWith('.bal') || lowerContent.startsWith('/bal')) {
      const bal = userBalances[userId] || 0
      await message.reply('💰 Your balance: **' + bal + ' Cat Coins**.')
      return
    }
    if (lowerContent.startsWith('/order')) {
      const args = content.slice(6).trim().split(/\\s+/).filter(Boolean)
      if (args.length < 1) { await message.reply('⚠️ Usage: `/order <kit> <amount>`'); return }
      const { kitInput, amountInput } = parseOrderArgs(args)
      const mcName = registrations[userId]
      if (!mcName) { await message.reply('❌ You must `/register <name>` first!'); return }
      await processOrder({ discordId: userId, mcName, kitInput, amountInput, replyFn: async text => await message.reply(text), source: 'discord' })
      return
    }
    if (lowerContent.startsWith('/gamble')) {
      if (message.channel.id !== GAMBLE_CHANNEL_ID) { await message.reply('⚠️ Use the <#' + GAMBLE_CHANNEL_ID + '> channel to gamble!'); return }
      const args = content.slice(7).trim().split(/\\s+/).filter(Boolean)
      if (args.length === 0 || !/^\\d+$/.test(args[0])) { await message.reply('⚠️ Usage: `/gamble <amount>`'); return }
      if (onGambleCooldown(userId)) { await message.reply('⚠️ Slow down!'); return }
      const amount = parseInt(args[0], 10)
      const result = runGamble(userId, amount)
      if (!result.ok) {
        if (result.error === 'min') await message.reply('❌ Min bet ' + GAMBLE_MIN_BET + '.')
        else if (result.error === 'max') await message.reply('❌ Max bet ' + GAMBLE_MAX_BET + '.')
        else if (result.error === 'funds') await message.reply('❌ Insufficient funds. Bal: ' + result.balance)
        else await message.reply('❌ Error placing bet.')
        return
      }
      await message.reply(result.win ? '🎉 **WIN!** +' + result.amount + ' coins. ' + result.line + '\\nBalance: **' + result.balance + '**' : '💀 **LOSS!** -' + result.amount + ' coins. ' + result.line + '\\nBalance: **' + result.balance + '**')
      return
    }
    if (lowerContent.startsWith('/add admin') || lowerContent.startsWith('.add admin')) {
      if (!isKitAdmin(userId)) { await message.reply('❌ Only kit admins can promote others.'); return }
      const target = content.match(/admin\\s+<@!?(\\d+)>$/i) || content.match(/admin\\s+(\\d{17,20})$/i)
      if (!target) { await message.reply('⚠️ Usage: `/add admin @user`'); return }
      const targetId = target[1]
      if (!extraAdminIds.includes(targetId)) {
        extraAdminIds.push(targetId)
        rebuildAdminIds()
        saveData()
        await message.reply('✅ <@' + targetId + '> promoted to Admin.')
      } else { await message.reply('⚠️ User is already an admin.') }
      return
    }
    if (lowerContent.startsWith('/remove admin') || lowerContent.startsWith('.remove admin')) {
      if (!isKitAdmin(userId)) { await message.reply('❌ Only kit admins can remove admins.'); return }
      const target = content.match(/admin\\s+<@!?(\\d+)>$/i) || content.match(/admin\\s+(\\d{17,20})$/i)
      if (!target) { await message.reply('⚠️ Usage: `/remove admin @user`'); return }
      const targetId = target[1]
      if (extraAdminIds.includes(targetId)) {
        extraAdminIds = extraAdminIds.filter(id => id !== targetId)
        rebuildAdminIds()
        saveData()
        await message.reply('✅ <@' + targetId + '> removed from Admins.')
      } else { await message.reply('⚠️ User is not an extra admin.') }
      return
    }
    if (lowerContent.startsWith('/kit add') || lowerContent.startsWith('.kit add')) {
      if (!isKitAdmin(userId)) { await message.reply('❌ Only kit admins can edit kits.'); return }
      const parts = content.replace(/^[.\\/]kit\\s+add\\s+/i, '').trim().split(/\\s+/)
      if (parts.length < 2) { await message.reply('⚠️ Usage: `/kit add <NAME> <color/exact/any>`'); return }
      const kitName = parts[0].toUpperCase()
      const spec = parseShulkerSpec(parts[1])
      if (!spec) { await message.reply('❌ Invalid specification. Use a color, `shulker_box`, or `any`.'); return }
      KIT_RULES[kitName] = { ...spec, cost: 3 }
      saveData()
      await message.reply('✅ Kit **' + kitName + '** added/updated.')
      return
    }
    if (lowerContent.startsWith('/kit remove') || lowerContent.startsWith('.kit remove')) {
      if (!isKitAdmin(userId)) { await message.reply('❌ Only kit admins can edit kits.'); return }
      const kitName = content.replace(/^[.\\/]kit\\s+remove\\s+/i, '').trim().toUpperCase()
      if (!KIT_RULES[kitName]) { await message.reply('⚠️ Kit not found.'); return }
      delete KIT_RULES[kitName]
      saveData()
      await message.reply('✅ Kit **' + kitName + '** removed.')
      return
    }
    if (lowerContent.startsWith('/kit list') || lowerContent.startsWith('.kit list')) {
      await message.reply('📦 Available Kits: ' + listKitNames() + ' (Each costs 3 coins)')
      return
    }
  } catch (e) { log('Discord message error: ' + e.message) }
})

connectDiscord()
createBot()
